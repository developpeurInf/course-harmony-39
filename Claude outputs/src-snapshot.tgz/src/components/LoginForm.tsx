
import { useState } from "react";
import { useNavigate } from "@/lib/router";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { GraduationCap, BookOpen, LogIn } from "lucide-react";

const LoginForm = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const success = await login(email, password);
      if (success) {
        navigate("/dashboard");
      }
    } finally {
      setIsLoading(false);
    }
  };

  // For demo purposes, let's add helper buttons
  const loginAsProfessor = async () => {
    setEmail("smith@university.edu");
    setPassword("password");
    setIsLoading(true);
    
    try {
      const success = await login("smith@university.edu", "password");
      if (success) {
        navigate("/dashboard");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const loginAsStudent = async () => {
    setEmail("john@university.edu");
    setPassword("password");
    setIsLoading(true);
    
    try {
      const success = await login("john@university.edu", "password");
      if (success) {
        navigate("/dashboard");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-muted/30">
      <Card className="w-full max-w-[350px] shadow-lg animate-fade-in">
        <CardHeader className="space-y-1">
          <CardTitle className="text-lg font-semibold text-center">{t("login.title")}</CardTitle>
          <CardDescription className="text-center">
            {t("login.subtitle")}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">{t("form.email")}</Label>
              <Input
                id="email"
                type="email"
                placeholder="your.email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="password">{t("form.password")}</Label>
                <a href="#" className="text-sm text-primary hover:underline">
                  {t("login.forgot")}
                </a>
              </div>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <span className="flex items-center">
                  <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground"></span>
                  {t("login.logging")}
                </span>
              ) : (
                <span className="flex items-center">
                  <LogIn className="mr-2 h-4 w-4" />
                  {t("nav.login")}
                </span>
              )}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <div className="text-sm text-muted-foreground text-center mb-2">
            {t("login.demo")}
          </div>
          <div className="flex gap-2 w-full">
            <Button
              variant="outline"
              className="w-full text-xs"
              onClick={loginAsProfessor}
              disabled={isLoading}
            >
              <GraduationCap className="mr-1 h-4 w-4" />
              {t("profile.professor")}
            </Button>
            <Button
              variant="outline"
              className="w-full text-xs"
              onClick={loginAsStudent}
              disabled={isLoading}
            >
              <BookOpen className="mr-1 h-4 w-4" />
              {t("profile.student")}
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};

export default LoginForm;
