import { useState } from "react";
import { useNavigate } from "@/lib/router";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Bell,
  CheckCheck,
  Trash2,
  BookOpen,
  FileText,
  GraduationCap,
  Clock,
  AlertTriangle,
  Info,
  Check,
  Sparkles,
  Inbox
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { usePopupMenu } from "@/components/ui/use-popup-menu";
import { useNotifications, Notification, NotificationType } from "@/contexts/NotificationContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";
import { useAppSettings } from "@/contexts/AppSettingsContext";

const NotificationBellInner = () => {
  const {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearAllNotifications
  } = useNotifications();

  const { language } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [filter, setFilter] = useState<"all" | "unread">("all");
  const [confirmClear, setConfirmClear] = useState(false);
  const navigate = useNavigate();
  // Fermeture au clic extérieur / Échap, focus initial, aria-expanded / aria-controls
  const { containerRef, triggerRef, menuRef, menuId, triggerProps } = usePopupMenu(isOpen, setIsOpen);

  const isRtl = language === "ar";

  const t = (fr: string, ar: string, en: string) =>
    language === "ar" ? ar : language === "fr" ? fr : en;

  const handleNotificationClick = async (notification: Notification) => {
    if (!notification.read) {
      await markAsRead(notification.id);
    }

    if (notification.type.includes('course')) {
      navigate('/courses');
    } else if (notification.type.includes('exercise')) {
      navigate('/exercises');
    } else if (notification.type.includes('exam')) {
      navigate('/exams');
    }

    setIsOpen(false);
  };

  const formatRelativeTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHours = Math.floor(diffMin / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMin < 1) return t("À l'instant", "الآن", "Just now");
    if (diffMin < 60) return t(`Il y a ${diffMin} min`, `منذ ${diffMin} د`, `${diffMin}m ago`);
    if (diffHours < 24) return t(`Il y a ${diffHours} h`, `منذ ${diffHours} س`, `${diffHours}h ago`);
    if (diffDays === 1) return t("Hier", "أمس", "Yesterday");
    if (diffDays < 7) return t(`Il y a ${diffDays} j`, `منذ ${diffDays} أيام`, `${diffDays}d ago`);

    return date.toLocaleDateString(language === "ar" ? "ar-MA" : language === "en" ? "en-GB" : "fr-FR", {
      month: "short",
      day: "numeric",
    });
  };

  // Helper to extract the item title (inside quotes or fallback)
  const extractItemTitle = (notification: Notification): string => {
    const match = notification.message.match(/"([^"]+)"/) || notification.title.match(/"([^"]+)"/);
    if (match && match[1]) {
      return match[1];
    }
    return "";
  };

  // Localize title and formatted message parts
  const getLocalizedContent = (notification: Notification) => {
    const itemTitle = extractItemTitle(notification);
    const type = notification.type;

    if (type === 'course_added') {
      return {
        title: t("Nouveau cours disponible", "درس جديد متوفر", "New course available"),
        prefix: t("Le cours ", "تم نشر الدرس ", "The course "),
        itemTitle: itemTitle ? `"${itemTitle}"` : "",
        suffix: t(" a été publié pour votre classe.", " لقسمك.", " has been published for your class."),
        fallbackMessage: notification.message
      };
    }

    if (type === 'course_updated') {
      return {
        title: t("Cours mis à jour", "تم تحديث الدرس", "Course updated"),
        prefix: t("Le contenu du cours ", "تم تعديل محتوى الدرس ", "The content of course "),
        itemTitle: itemTitle ? `"${itemTitle}"` : "",
        suffix: t(". Veuillez le consulter.", ". يرجى الاطلاع عليه.", ". Please check it out."),
        fallbackMessage: notification.message
      };
    }

    if (type === 'course_deleted') {
      return {
        title: t("Cours retiré", "تم حذف الدرس", "Course removed"),
        prefix: t("Le cours ", "تم حذف الدرس ", "The course "),
        itemTitle: itemTitle ? `"${itemTitle}"` : "",
        suffix: t(" a été retiré par votre professeur.", " من قبل أستاذك.", " was removed by your professor."),
        fallbackMessage: notification.message
      };
    }

    if (type === 'exercise_added') {
      return {
        title: t("Nouvel exercice disponible", "تمرين جديد متوفر", "New exercise available"),
        prefix: t("L'exercice ", "تمت إضافة التمرين ", "The exercise "),
        itemTitle: itemTitle ? `"${itemTitle}"` : "",
        suffix: t(" a été ajouté à votre classe.", " لقسمك.", " has been added to your class."),
        fallbackMessage: notification.message
      };
    }

    if (type === 'exercise_updated') {
      return {
        title: t("Exercice mis à jour", "تم تحديث التمرين", "Exercise updated"),
        prefix: t("L'exercice ", "تم تعديل التمرين ", "The exercise "),
        itemTitle: itemTitle ? `"${itemTitle}"` : "",
        suffix: t(". Veuillez le consulter.", ". يرجى الاطلاع عليه.", ". Please check it out."),
        fallbackMessage: notification.message
      };
    }

    if (type === 'exercise_deleted') {
      return {
        title: t("Exercice retiré", "تم حذف التمرين", "Exercise removed"),
        prefix: t("L'exercice ", "تم حذف التمرين ", "The exercise "),
        itemTitle: itemTitle ? `"${itemTitle}"` : "",
        suffix: t(" a été supprimé.", ".", " was removed."),
        fallbackMessage: notification.message
      };
    }

    if (type === 'exam_added') {
      return {
        title: t("Nouvelle évaluation programmée", "تقييم جديد مبرمج", "New assessment scheduled"),
        prefix: t("L'évaluation ", "تمت برمجة التقييم ", "The assessment "),
        itemTitle: itemTitle ? `"${itemTitle}"` : "",
        suffix: t(" a été programmée pour votre classe.", " لقسمك.", " has been scheduled for your class."),
        fallbackMessage: notification.message
      };
    }

    if (type === 'exam_updated') {
      return {
        title: t("Évaluation mise à jour", "تم تحديث التقييم", "Assessment updated"),
        prefix: t("L'évaluation ", "تم تعديل التقييم ", "The assessment "),
        itemTitle: itemTitle ? `"${itemTitle}"` : "",
        suffix: t(". Veuillez vérifier les détails.", ". يرجى التحقق من التفاصيل.", ". Please check the details."),
        fallbackMessage: notification.message
      };
    }

    if (type === 'exam_deleted') {
      return {
        title: t("Évaluation annulée", "تم إلغاء التقييم", "Assessment cancelled"),
        prefix: t("L'évaluation ", "تم إلغاء التقييم ", "The assessment "),
        itemTitle: itemTitle ? `"${itemTitle}"` : "",
        suffix: t(" a été annulée.", ".", " was cancelled."),
        fallbackMessage: notification.message
      };
    }

    if (type === 'exam_reminder') {
      return {
        title: t("Rappel : évaluation dans moins de 24 h", "تذكير: تقييم خلال أقل من 24 ساعة", "Reminder: assessment in less than 24 h"),
        prefix: t("L'évaluation ", "التقييم ", "The assessment "),
        itemTitle: itemTitle ? `"${itemTitle}"` : "",
        suffix: t(" aura lieu très prochainement. Préparez-vous !", " سيُجرى قريباً جداً. استعد جيداً!", " will take place very soon. Get ready!"),
        fallbackMessage: notification.message
      };
    }

    return {
      // anciennes notifications enregistrées avec un emoji en tête
      title: notification.title.replace(/^[\u2190-\u2BFF\uD83C-\uDBFF\uDC00-\uDFFF\uFE0F\s]+/, ""),
      prefix: "",
      itemTitle: "",
      suffix: "",
      fallbackMessage: notification.message
    };
  };

  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case 'course_added':
        return {
          icon: BookOpen,
          bg: "bg-primary/10 text-primary  border-primary/30",
          badge: t("Nouveau cours", "درس جديد", "New Course")
        };
      case 'course_updated':
        return {
          icon: BookOpen,
          bg: "bg-primary/10 text-primary  border-primary/30",
          badge: t("Cours mis à jour", "تحديث درس", "Course Updated")
        };
      case 'course_deleted':
        return {
          icon: Trash2,
          bg: "bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30",
          badge: t("Suppression", "حذف", "Deleted")
        };
      case 'exercise_added':
        return {
          icon: FileText,
          bg: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
          badge: t("Nouvel exercice", "تمرين جديد", "New Exercise")
        };
      case 'exercise_updated':
        return {
          icon: FileText,
          bg: "bg-primary/10 text-primary  border-primary/30",
          badge: t("Exercice mis à jour", "تحديث تمرين", "Exercise Updated")
        };
      case 'exercise_deleted':
        return {
          icon: Trash2,
          bg: "bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30",
          badge: t("Suppression", "حذف", "Deleted")
        };
      case 'exam_added':
        return {
          icon: GraduationCap,
          bg: "bg-primary/10 text-primary  border-primary/30",
          badge: t("Nouvelle évaluation", "تقييم جديد", "New Exam")
        };
      case 'exam_updated':
        return {
          icon: GraduationCap,
          bg: "bg-primary/10 text-primary  border-primary/30",
          badge: t("Évaluation mise à jour", "تحديث تقييم", "Exam Updated")
        };
      case 'exam_deleted':
        return {
          icon: Trash2,
          bg: "bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30",
          badge: t("Annulation", "إلغاء", "Cancelled")
        };
      case 'exam_reminder':
        return {
          icon: Clock,
          bg: "bg-amber-500/20 text-amber-600 dark:text-amber-400 border-amber-500/40 animate-pulse",
          badge: t("Rappel < 24h", "تذكير < 24س", "Reminder < 24h")
        };
      case 'warning':
        return {
          icon: AlertTriangle,
          bg: "bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30",
          badge: t("Alerte", "تنبيه", "Alert")
        };
      default:
        return {
          icon: Info,
          bg: "bg-primary/15 text-primary border-primary/30",
          badge: t("Info", "معلومة", "Info")
        };
    }
  };

  const filteredNotifications = notifications.filter(n => {
    if (n.type === '__DELETED__' || n.type === '__CLEAR_ALL__' || n.title === '__RESET_ROOM_NOTIFICATIONS__') return false;
    if (filter === "unread") return !n.read;
    return true;
  });

  const bellLabel =
    unreadCount > 0
      ? t(`Notifications (${unreadCount} non lue(s))`, `الإشعارات (${unreadCount} غير مقروءة)`, `Notifications (${unreadCount} unread)`)
      : t("Notifications", "الإشعارات", "Notifications");

  const actionBtn = "h-9 w-9 text-muted-foreground rounded-lg";

  return (
    <div ref={containerRef} className="relative inline-block">
      <Button
        ref={triggerRef}
        type="button"
        variant="ghost"
        size="icon"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setIsOpen((prev) => !prev);
        }}
        className={cn(
          "relative h-10 w-10 rounded-full transition-colors cursor-pointer select-none",
          isOpen ? "bg-muted text-primary" : "hover:bg-muted"
        )}
        aria-label={bellLabel}
        title={bellLabel}
        {...triggerProps}
      >
        <Bell className={cn("h-5 w-5 transition-transform pointer-events-none", unreadCount > 0 && "text-primary animate-wiggle")} />
        {unreadCount > 0 && (
          <span
            aria-hidden="true"
            className="absolute -top-0.5 -right-0.5 rtl:right-auto rtl:-left-0.5 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-destructive px-1 text-[11px] font-semibold text-destructive-foreground shadow-md ring-2 ring-background animate-scale-in pointer-events-none"
          >
            {unreadCount > 99 ? "99+" : unreadCount}
          </span>
        )}
      </Button>

      {isOpen && (
        <div
          ref={menuRef}
          id={menuId}
          role="dialog"
          aria-label={t("Notifications", "الإشعارات", "Notifications")}
          dir={isRtl ? "rtl" : "ltr"}
          className={cn(
            // Téléphone : panneau pleine largeur sous la barre du haut ; à partir de sm : menu ancré au bouton
            "notif-panel fixed left-2 right-2 top-[4.25rem] sm:absolute sm:top-full sm:left-auto sm:right-0 sm:rtl:right-auto sm:rtl:left-0 sm:mt-1.5 sm:w-[420px] sm:max-w-[95vw]",
            "p-0 shadow-2xl border border-border bg-card text-card-foreground rounded-xl overflow-hidden z-50 animate-in fade-in-50 zoom-in-95"
          )}
        >
        {/* Header */}
        <div className="flex items-center justify-between gap-2 px-4 py-3 border-b bg-muted/40">
          <div className="flex items-center gap-2 min-w-0">
            <div className="p-1.5 rounded-lg bg-primary/10 text-primary">
              <Bell className="h-4 w-4" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-semibold leading-none">
                {t("Notifications", "الإشعارات", "Notifications")}
              </h3>
              <p className="text-xs text-muted-foreground mt-1">
                {unreadCount > 0
                  ? t(`${unreadCount} non lue(s)`, `${unreadCount} غير مقروءة`, `${unreadCount} unread`)
                  : t("Toutes les notifications sont lues", "جميع الإشعارات مقروءة", "All caught up")}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 flex-shrink-0">
            <TooltipProvider>
              {unreadCount > 0 && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => markAllAsRead()}
                      className={cn(actionBtn, "hover:text-primary")}
                      aria-label={t("Tout marquer comme lu", "تحديد الكل كمقروء", "Mark all as read")}
                    >
                      <CheckCheck className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">
                    <p className="text-xs">
                      {t("Tout marquer comme lu", "تحديد الكل كمقروء", "Mark all as read")}
                    </p>
                  </TooltipContent>
                </Tooltip>
              )}

              {notifications.length > 0 && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => setConfirmClear(true)}
                      className={cn(actionBtn, "hover:text-destructive")}
                      aria-label={t("Tout effacer", "حذف الكل", "Clear all")}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">
                    <p className="text-xs">
                      {t("Tout effacer", "حذف الكل", "Clear all")}
                    </p>
                  </TooltipContent>
                </Tooltip>
              )}
            </TooltipProvider>
          </div>
        </div>

        {/* Filter Tabs */}
        {notifications.length > 0 && (
          <div className="flex items-center gap-2 px-4 py-2 border-b bg-background/50 text-xs" role="group">
            <button
              type="button"
              onClick={() => setFilter("all")}
              aria-pressed={filter === "all"}
              className={cn(
                "min-h-[36px] px-3 py-1.5 rounded-md font-medium transition-all",
                filter === "all"
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )}
            >
              {t("Toutes", "الكل", "All")} ({notifications.length})
            </button>
            <button
              type="button"
              onClick={() => setFilter("unread")}
              aria-pressed={filter === "unread"}
              className={cn(
                "min-h-[36px] px-3 py-1.5 rounded-md font-medium transition-all flex items-center gap-1.5",
                filter === "unread"
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )}
            >
              {t("Non lues", "غير مقروءة", "Unread")}
              {unreadCount > 0 && (
                <span className={cn(
                  "px-1.5 rounded-full text-[10px] font-semibold",
                  filter === "unread" ? "bg-primary-foreground/20 text-primary-foreground" : "bg-primary/10 text-primary"
                )}>
                  {unreadCount}
                </span>
              )}
            </button>
          </div>
        )}

        {/* Notifications List */}
        <ScrollArea className="h-[360px] max-h-[60vh]">
          {filteredNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
              <div className="h-12 w-12 rounded-full bg-muted/60 flex items-center justify-center text-muted-foreground mb-3 border border-border/50">
                {filter === "unread" ? <Sparkles className="h-6 w-6 text-primary" /> : <Inbox className="h-6 w-6" />}
              </div>
              <h4 className="text-sm font-semibold text-foreground">
                {filter === "unread"
                  ? t("Aucune notification non lue", "لا توجد إشعارات غير مقروءة", "No unread notifications")
                  : t("Aucune notification pour le moment", "لا توجد إشعارات حالياً", "No notifications yet")}
              </h4>
              <p className="text-xs text-muted-foreground mt-1 max-w-[240px]">
                {filter === "unread"
                  ? t("Vous avez consulté toutes vos alertes !", "لقد اطلعت على جميع الإشعارات!", "You're all caught up!")
                  : t("Les nouveaux cours, exercices et examens apparaîtront ici.", "ستظهر هنا الدروس والتمارين والامتحانات الجديدة.", "New courses, exercises and exams will appear here.")}
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-border/50">
              {filteredNotifications.map((notification) => {
                const iconConfig = getNotificationIcon(notification.type);
                const IconComponent = iconConfig.icon;
                const localized = getLocalizedContent(notification);

                return (
                  <li
                    key={notification.id}
                    dir={isRtl ? "rtl" : "ltr"}
                    className={cn(
                      "group relative flex items-stretch transition-colors hover:bg-muted/60",
                      !notification.read && "bg-primary/[0.04] dark:bg-primary/[0.07]"
                    )}
                  >
                    {/* Zone principale : un vrai bouton (focus clavier, Entrée / Espace) */}
                    <button
                      type="button"
                      onClick={() => handleNotificationClick(notification)}
                      className="flex flex-1 min-w-0 items-start gap-3 p-3.5 text-start focus:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring"
                    >
                      {/* Icon with colored badge container */}
                      <span
                        className={cn(
                          "mt-0.5 p-2 rounded-xl border flex-shrink-0 transition-transform",
                          iconConfig.bg
                        )}
                        aria-hidden="true"
                      >
                        <IconComponent className="h-4 w-4" />
                      </span>

                      {/* Content */}
                      <span className="flex flex-1 min-w-0 flex-col gap-1">
                        <span className="flex items-center justify-between gap-2">
                          <span className="flex min-w-0 items-center gap-1.5">
                            {!notification.read && (
                              <span className="h-2 w-2 flex-shrink-0 rounded-full bg-primary" aria-hidden="true" />
                            )}
                            <span className="text-xs font-semibold text-foreground leading-snug line-clamp-1">
                              {localized.title}
                            </span>
                            {!notification.read && (
                              <span className="sr-only">{t("(non lue)", "(غير مقروءة)", "(unread)")}</span>
                            )}
                          </span>
                          <span className="text-[11px] text-muted-foreground flex-shrink-0 font-medium">
                            {formatRelativeTime(notification.created_at)}
                          </span>
                        </span>

                        {/* BiDi-safe message rendering */}
                        <span className="block text-xs text-muted-foreground leading-relaxed line-clamp-2" dir={isRtl ? "rtl" : "ltr"}>
                          {localized.prefix}
                          {localized.itemTitle && (
                            <bdi className="font-semibold text-foreground mx-0.5">
                              {localized.itemTitle}
                            </bdi>
                          )}
                          {localized.suffix || localized.fallbackMessage}
                        </span>

                        <span className="pt-1">
                          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-muted text-muted-foreground border border-border/40">
                            {iconConfig.badge}
                          </span>
                        </span>
                      </span>
                    </button>

                    {/* Actions rapides (visibles au survol, au focus clavier et toujours sur écran tactile) */}
                    <div className="flex flex-col items-center justify-center gap-1 py-2 pr-2 rtl:pr-0 rtl:pl-2 opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 [@media(hover:none)]:opacity-100 transition-opacity">
                      {!notification.read && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className={cn(actionBtn, "hover:text-primary hover:bg-primary/10")}
                          title={t("Marquer comme lu", "تحديد كمقروء", "Mark as read")}
                          aria-label={t("Marquer comme lu", "تحديد كمقروء", "Mark as read")}
                          onClick={() => markAsRead(notification.id)}
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className={cn(actionBtn, "hover:text-destructive hover:bg-destructive/10")}
                        title={t("Supprimer la notification", "حذف الإشعار", "Delete notification")}
                        aria-label={t("Supprimer la notification", "حذف الإشعار", "Delete notification")}
                        onClick={() => deleteNotification(notification.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </ScrollArea>
        </div>
      )}

      {/* Confirmation avant de tout effacer (hors du panneau : survit à sa fermeture) */}
      <AlertDialog open={confirmClear} onOpenChange={setConfirmClear}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {t("Effacer toutes les notifications ?", "حذف جميع الإشعارات؟", "Clear all notifications?")}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {t(
                "Toutes vos notifications seront supprimées définitivement. Cette action est irréversible.",
                "سيتم حذف جميع إشعاراتك نهائياً. لا يمكن التراجع عن هذا الإجراء.",
                "All your notifications will be permanently deleted. This cannot be undone."
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("Annuler", "إلغاء", "Cancel")}</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                clearAllNotifications();
                setConfirmClear(false);
              }}
            >
              {t("Tout effacer", "حذف الكل", "Clear all")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

/** Cloche des notifications : masquée quand l'administration désactive le module « notifications ». */
export const NotificationBell = () => {
  const { feature } = useAppSettings();
  if (!feature("notifications")) return null;
  return <NotificationBellInner />;
};

export default NotificationBell;