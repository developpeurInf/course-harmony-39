// Complete Arabic translations dictionary and helper utilities
// Customized for Moroccan Educational System (الدروس, التلاميذ, الأقسام)

export const ARABIC_DICTIONARY: Record<string, string> = {
  "I'm a Professor": "أنا أستاذ",
  "I'm a Student": "أنا تلميذ",
  "Professor": "أستاذ",
  "Student": "تلميذ",
  "Welcome": "مرحباً",
  "Choose your account type to continue": "اختر نوع حسابك للمتابعة",
  "Welcome Back": "مرحباً بعودتك",
  "Sign in to your account to continue": "سجل الدخول إلى حسابك للمتابعة",
  "Create Account": "إنشاء حساب",
  "Create a new account to get started": "أنشئ حساباً جديداً للبدء",
  "Reset Password": "إعادة تعيين كلمة المرور",
  "Enter your email to receive a password reset link": "أدخل بريدك الإلكتروني لتلقي رابط إعادة تعيين كلمة المرور",
  "Verify Your Email": "تحقق من بريدك الإلكتروني",
  "Enter the 6-digit confirmation code sent to your email": "أدخل رمز التأكيد المكون من 6 أرقام المرسل إلى بريدك الإلكتروني",
  "Username": "رمز مسار",
  "Enter your username": "أدخل رمز مسار",
  "Code Massar": "رمز مسار",
  "Enter your Code Massar": "أدخل رمز مسار",
  "Email": "البريد الإلكتروني",
  "Enter your email": "أدخل بريدك الإلكتروني",
  "Password": "كلمة المرور",
  "Enter your password": "أدخل كلمة المرور",
  "Temporary Password": "كلمة المرور المؤقتة",
  "Enter your temporary password": "أدخل كلمة المرور المؤقتة",
  "Full Name": "الاسم الكامل",
  "Enter your full name": "أدخل اسمك الكامل",
  "Role": "الدور",
  "Sign In": "تسجيل الدخول",
  "Signing In...": "جاري تسجيل الدخول...",
  "Creating Account...": "جاري إنشاء الحساب...",
  "Sending...": "جاري الإرسال...",
  "Send Reset Link": "إرسال رابط إعادة التعيين",
  "Forgot your password?": "هل نسيت كلمة المرور؟",
  "Have a confirmation code?": "هل لديك رمز تأكيد؟",
  "Don't have an account? Sign up": "ليس لديك حساب؟ اشترك الآن",
  "Already have an account? Sign in": "لديك حساب بالفعل؟ تسجيل الدخول",
  "or": "أو",
  "Please enter your email first": "يرجى إدخال بريدك الإلكتروني أولاً",
  "Please enter the confirmation code or link": "يرجى إدخال رمز التأكيد أو الرابط",
  "Un email de confirmation a été envoyé à :": "تم إرسال بريد إلكتروني للتأكيد إلى:",
  "Deux façons de confirmer :": "طريقتان للتأكيد:",
  "1. Cliquez sur le lien Confirm your mail dans votre email.": "1. انقر على رابط تأكيد بريدك في الرسالة الواردة.",
  "2. Ou entrez votre code / collez le lien ci-dessous :": "2. أو أدخل الرمز / الصق الرابط أدناه:",
  "Code à 6 chiffres": "رمز مكون من 6 أرقام",
  "Lien ou token de confirmation": "رابط أو رمز التأكيد",
  "Collez le lien ou token reçu par email...": "الصق الرابط أو الرمز المستلم عبر البريد...",
  "← Revenir au code à 6 chiffres": "← العودة إلى الرمز المكون من 6 أرقام",
  "Votre email contient un lien ? Cliquez ici pour le coller": "هل تحتوي رسالتك على رابط؟ انقر هنا للصقه",
  "Vérification en cours...": "جاري التحقق...",
  "Confirmer": "تأكيد",
  "Vous n'avez rien reçu ? Renvoyer": "لم تستلم شيئاً؟ إعادة الإرسال",
  "Retour à la connexion": "العودة إلى تسجيل الدخول",
  "Confirm your mail": "تأكيد بريدك الإلكتروني",
  "Dashboard": "لوحة التحكم",
  "Rooms": "الأقسام",
  "Courses": "الدروس",
  "Exercises": "التمارين",
  "Exams": "الامتحانات",
  "Students": "التلاميذ",
  "Students Activities": "أنشطة التلاميذ",
  "Reports": "التقارير",
  "Manage Classes": "إدارة الأقسام",
  "Profile": "الملف الشخصي",
  "Settings": "الإعدادات",
  "Logout": "تسجيل الخروج",
  "Account": "الحساب",
  "Theme": "المظهر",
  "Language": "اللغة",
  "Save": "حفظ",
  "Save Changes": "حفظ التغييرات",
  "Cancel": "إلغاء",
  "Delete": "حذف",
  "Edit": "تعديل",
  "Upload": "رفع",
  "Download": "تنزيل",
  "View": "عرض",
  "Close": "إغلاق",
  "Done": "تم",
  "Actions": "الإجراءات",
  "Status": "الحالة",
  "Visible": "مرئي",
  "Hidden": "مخفي",
  "Search": "بحث",
  "Filter": "تصفية",
  "All": "الكل",
  "Yes": "نعم",
  "No": "لا",
  "Back": "رجوع",
  "Next": "التالي",
  "Previous": "السابق",
  "Loading...": "جاري التحميل...",
  "Submit": "إرسال",
  "Submitting...": "جاري الإرسال...",
  "Total": "الإجمالي",
  "Name": "الاسم",
  "Date": "التاريخ",
  "Date & Time": "التاريخ والوقت",
  "Time": "الوقت",
  "Duration": "المدة",
  "Score": "الدرجة",
  "Details": "التفاصيل",
  "More": "المزيد",
  "Click here": "انقر هنا",
  "Add Room": "إضافة قسم",
  "Add New Room": "إضافة قسم جديد",
  "Create New Room": "إنشاء قسم جديد",
  "Room Name": "اسم القسم",
  "Create a new room to organize courses.": "إنشاء قسم جديد لتنظيم الدروس.",
  "Create Room": "إنشاء قسم",
  "Edit Room": "تعديل القسم",
  "Delete Room": "حذف القسم",
  "Delete room": "حذف القسم",
  "Manage your rooms and associated courses": "إدارة أقسامك والدروس المرتبطة بها",
  "View available rooms and their courses": "عرض الأقسام المتاحة ودروسها",
  "Switch to list view": "التبديل إلى عرض القائمة",
  "Switch to grid view": "التبديل إلى عرض الشبكة",
  "Visible to students": "مرئي للتلاميذ",
  "Enter room description": "أدخل وصف الغرفة",
  "e.g., Computer Science Department": "مثال: قسم علوم الحاسوب",
  "Are you sure you want to delete this room? This action cannot be undone.": "هل أنت متأكد من حذف هذا القسم؟ لا يمكن التراجع عن هذا الإجراء.",
  "No rooms found": "لم يتم العثور على أي قسم",
  "No rooms available": "لا توجد أقسام متاحة",
  "Add Your First Room": "أضف قسمك الأول",
  "Manage Courses": "إدارة الدروس",
  "View Courses": "عرض الدروس",
  "courses in this room": "دروس في هذا القسم",
  "Courses in this room": "دروس في هذا القسم",
  "Courses in this room:": "الدروس في هذا القسم:",
  "Active courses": "دروس نشطة",
  "Enrolled students": "تلاميذ مسجلون",
  "Across all rooms": "عبر جميع الأقسام",
  "Across all courses": "عبر جميع الدروس",
  "Class Management": "إدارة الأقسام",
  "Class Name": "اسم القسم",
  "Class Name *": "اسم القسم *",
  "Class Statistics": "إحصائيات القسم",
  "Class Average": "متوسط القسم",
  "Class not found.": "لم يتم العثور على القسم.",
  "Access denied. Only professors can manage classes.": "تم رفض الوصول. يمكن للأساتذة فقط إدارة الأقسام.",
  "Add Class": "إضافة قسم",
  "Create Class": "إنشاء قسم",
  "Create New Class": "إنشاء قسم جديد",
  "Create Your First Class": "أنشئ قسمك الأول",
  "Create your first class to start organizing courses and students": "أنشئ قسمك الأول لبدء تنظيم الدروس والتلاميذ",
  "Edit Class": "تعديل القسم",
  "Delete Class": "حذف القسم",
  "Delete Everything": "حذف كل شيء",
  "Classes": "الأقسام",
  "Manage your classes": "إدارة أقسامك الدراسية",
  "Manage your classes and their associated content": "إدارة أقسامك ومحتوياتها المرتبطة",
  "Set up a new class to organize your courses and students": "إعداد قسم جديد لتنظيم دروسك وتلاميذك",
  "Set up a new room to organize your courses and students": "إعداد قسم جديد لتنظيم دروسك وتلاميذك",
  "Enter class name...": "أدخل اسم القسم...",
  "Enter class description...": "أدخل وصف القسم...",
  "Enter room name...": "أدخل اسم القسم...",
  "Enter room description...": "أدخل وصف القسم...",
  "Make class visible to students": "إتاحة القسم لظهور التلاميذ",
  "Make room visible to students": "إتاحة القسم لظهور التلاميذ",
  "Room Details": "تفاصيل القسم",
  "Class Details": "تفاصيل القسم",
  "Room Name *": "اسم القسم *",
  "Enter the information for your new room": "أدخل معلومات قسمك الجديد",
  "Enter the information for your new class": "أدخل معلومات قسمك الجديد",
  "Room created successfully!": "تم إنشاء القسم بنجاح!",
  "Class created successfully!": "تم إنشاء القسم بنجاح!",
  "Failed to create room": "فشل في إنشاء القسم",
  "Failed to create class": "فشل في إنشاء القسم",
  "Room name is required": "اسم القسم مطلوب",
  "Class name is required": "اسم القسم مطلوب",
  "Visibility": "الظهور",
  "Visibility:": "الظهور:",
  "Add Course": "إضافة درس",
  "Add New Course": "إضافة درس جديد",
  "Add course": "إضافة درس",
  "Course": "الدرس",
  "Course Title": "عنوان الدرس",
  "Course Title *": "عنوان الدرس *",
  "Course Name": "اسم الدرس",
  "Course Description": "وصف الدرس",
  "Course description": "وصف الدرس",
  "Course title": "عنوان الدرس",
  "Create a new course for your students.": "إنشاء درس جديد لتلاميذك.",
  "Create a new course and make it available to students.": "إنشاء درس جديد وإتاحته للتلاميذ.",
  "Create Course": "إنشاء درس",
  "Edit Course": "تعديل الدرس",
  "Delete Course": "حذف الدرس",
  "Delete course": "حذف الدرس",
  "Filter by Room": "تصفية حسب الغرفة",
  "Filter by course": "تصفية حسب الدرس",
  "All Rooms": "جميع الغرف",
  "All Courses": "جميع الدروس",
  "Manage your courses and course materials": "إدارة دروسك ومواد الدرس",
  "View your enrolled courses and course materials": "عرض دروسك المسجلة ومواد الدروس",
  "No courses found": "لم يتم العثور على دروس",
  "No courses available": "لا توجد دروس متاحة",
  "Add Your First Course": "أضف درسك الأول",
  "Course Materials": "مواد الدرس",
  "Course Materials (PDFs)": "مواد الدرس (ملفات PDF)",
  "Upload PDF": "رفع ملف PDF",
  "Upload Materials": "رفع المواد",
  "Attach PDF Files": "إرفاق ملفات PDF",
  "Enroll Student": "تسجيل تلميذ",
  "Enroll Students": "تسجيل تلاميذ",
  "Unenroll": "إلغاء التسجيل",
  "Select a student to enroll": "اختر تلميذاً لتسجيله",
  "Select student": "اختر التلميذ",
  "Select room": "اختر الغرفة",
  "Room": "الغرفة",
  "Select a room": "اختر غرفة",
  "Select Room": "اختر الغرفة",
  "No room selected": "لم يتم اختيار غرفة",
  "Description": "الوصف",
  "Enter course description": "أدخل وصف الدرس",
  "Enter course title": "أدخل عنوان الدرس",
  "e.g., Introduction to Programming": "مثال: مقدمة في البرمجة",
  "Are you sure you want to delete this course? This action cannot be undone.": "هل أنت متأكد من حذف هذا الدرس؟ لا يمكن التراجع عن هذا الإجراء.",
  "Are you sure you want to delete this course and all related data (materials, exercises, exams, enrollments)? This action cannot be undone.": "هل أنت متأكد من حذف هذا الدرس وجميع البيانات المتعلقة به (المواد، التمارين، الامتحانات، التسجيلات)؟ لا يمكن التراجع عن هذا الإجراء.",
  "Deleting...": "جاري الحذف...",
  "Saving...": "جاري الحفظ...",
  "Enrolling...": "جاري التسجيل...",
  "Students Enrolled": "التلاميذ المسجلون",
  "Enrolled": "مسجل",
  "Not enrolled": "غير مسجل",
  "View Materials": "عرض المواد",
  "Download Materials": "تنزيل المواد",
  "No materials uploaded yet": "لم يتم رفع أي مواد بعد",
  "A PDF file is currently attached to this item": "ملف PDF مرفق حالياً بهذا العنصر",
  "Replace PDF File": "استبدال ملف PDF",
  "Choose File": "اختر ملفاً",
  "Change Photo": "تغيير الصورة",
  "Drag and drop PDF files here, or click to select": "اسحب وأفلت ملفات PDF هنا، أو انقر للاختيار",
  "Selected Files": "الملفات المحددة",
  "Remove": "إزالة",
  "Remove file": "إزالة الملف",
  "PDF Preview": "معاينة PDF",
  "Open PDF": "فتح PDF",
  "Course Analytics": "تحليلات الدرس",
  "Show": "عرض",
  "Hide": "إخفاء",
  "Add Exercise": "إضافة تمرين",
  "Add New Exercise": "إضافة تمرين جديد",
  "Create a new exercise and link it to a course": "إنشاء تمرين جديد وربطه بدرس",
  "Add Exam": "إضافة امتحان",
  "Add New Exam": "إضافة امتحان جديد",
  "Schedule New Exam": "جدولة امتحان جديد",
  "Schedule Exam": "جدولة امتحان",
  "Schedule Your First Exam": "جدولة امتحانك الأول",
  "Schedule Your First Exam..": "جدولة امتحانك الأول..",
  "Create a new exam for one of your courses.": "إنشاء امتحان جديد لأحد دروسك.",
  "Delete Exam": "حذف الامتحان",
  "Delete exam": "حذف الامتحان",
  "Are you sure you want to delete this exam? This action cannot be undone.": "هل أنت متأكد من حذف هذا الامتحان؟ لا يمكن التراجع عن هذا الإجراء.",
  "Are you sure you want to delete this exercise? This action cannot be undone.": "هل أنت متأكد من حذف هذا التمرين؟ لا يمكن التراجع عن هذا الإجراء.",
  "Add Your First Exercise": "أضف تمرينك الأول",
  "Add Your First Exam": "أضف امتحانك الأول",
  "Exercise Name": "اسم التمرين",
  "Exam Name": "اسم الامتحان",
  "Exam Title": "عنوان الامتحان",
  "Duration (minutes)": "المدة (بالدقائق)",
  "Start Time": "وقت البدء",
  "Due Date": "تاريخ الاستحقاق",
  "Start Date": "تاريخ البدء",
  "End Date": "تاريخ الانتهاء",
  "Passing Score": "درجة النجاح",
  "Passing score": "درجة النجاح",
  "Total Questions": "إجمالي الأسئلة",
  "Questions": "الأسئلة",
  "Question": "السؤال",
  "Add Question": "إضافة سؤال",
  "Add your first question below": "أضف سؤالك الأول أدناه",
  "Question Text": "نص السؤال",
  "Question Type": "نوع السؤال",
  "Multiple Choice": "اختيار من متعدد",
  "True/False": "صح / خطأ",
  "Short Answer": "إجابة قصيرة",
  "Regular Exam": "امتحان عادي",
  "Quiz": "اختبار قصير",
  "Points": "النقاط",
  "Options": "الخيارات",
  "Option": "الخيار",
  "Add Option": "إضافة خيار",
  "Correct Answer": "الإجابة الصحيحة",
  "Mark as correct": "تحديد كإجابة صحيحة",
  "Correct": "صحيح",
  "Incorrect": "غير صحيح",
  "Quiz Settings": "إعدادات الاختبار",
  "Quiz Results": "نتائج الاختبار",
  "Take Quiz": "بدء الاختبار",
  "Start Quiz": "بدء الاختبار",
  "Start Exam": "بدء الامتحان",
  "Submit Quiz": "تسليم الاختبار",
  "Submit Exam": "تسليم الامتحان",
  "Close Quiz": "إغلاق الاختبار",
  "Your Score": "درجتك",
  "Passed": "ناجح",
  "Failed": "راسب",
  "Upcoming": "قادم",
  "Past": "سابق",
  "Time Remaining": "الوقت المتبقي",
  "Time's Up!": "انتهى الوقت!",
  "Auto-submit when time expires": "تسليم تلقائي عند انتهاء الوقت",
  "Allow Multiple Attempts": "السماح بمحاولات متعددة",
  "Allow Answer Review": "السماح بمراجعة الإجابات",
  "Allow Corrections": "السماح بالتصحيحات",
  "Display score right after submission": "عرض النتيجة مباشرة بعد التسليم",
  "Attempt Settings": "إعدادات المحاولات",
  "Answer Options": "خيارات الإجابة",
  "Answered": "تمت الإجابة",
  "Not Answered": "لم تتم الإجابة",
  "Total Score": "الدرجة الكلية",
  "Average Score": "متوسط الدرجات",
  "Avg Score": "متوسط الدرجات",
  "Avg. Time": "متوسط الوقت",
  "Completion Rate": "معدل الإكمال",
  "Add Image": "إضافة صورة",
  "Add Link": "إضافة رابط",
  "Create a hyperlink in your question.": "إنشاء رابط تشعبي في سؤالك.",
  "Delete Question": "حذف السؤال",
  "Edit Question": "تعديل السؤال",
  "Create questions and configure quiz settings": "إنشاء الأسئلة وضبط إعدادات الاختبار",
  "Manage your exercises and tests": "إدارة تمارينك واختباراتك",
  "Manage your exams and student assessments": "إدارة امتحاناتك وتقييمات التلاميذ",
  "View and complete assigned exercises": "عرض التمارين المعينة وإكمالها",
  "View and take assigned exams": "عرض الامتحانات المعينة وإجراؤها",
  "No exercises found": "لم يتم العثور على تمارين",
  "No exams found": "لم يتم العثور على امتحانات",
  "No exercises available": "لا توجد تمارين متاحة",
  "No exams available": "لا توجد امتحانات متاحة",
  "Manage and view exercises linked to courses": "إدارة وعرض التمارين المرتبطة بالدروس",
  "No exercises have been created yet. Add your first exercise to get started.": "لم يتم إنشاء أي تمارين بعد. أضف تمرينك الأول للبدء.",
  "Manage exams and tests for your courses": "إدارة الامتحانات والاختبارات الخاصة بدروسك",
  "You haven't scheduled any exams yet. Add your first exam to get started.": "لم تقم بجدولة أي امتحانات بعد. أضف امتحانك الأول للبدء.",
  "You don't have any exams scheduled yet.": "ليس لديك أي امتحانات مجدولة بعد.",
  "No exercises are currently available.": "لا توجد تمارين متاحة حالياً.",
  "Add Student": "إضافة تلميذ",
  "Add New Student": "إضافة تلميذ جديد",
  "Add student": "إضافة تلميذ",
  "Create a new student account. They will receive an email to verify their account.": "إنشاء حساب تلميذ جديد. سيتلقى بريداً إلكترونياً للتحقق من حسابه.",
  "Student Name": "اسم التلميذ",
  "Student Email": "البريد الإلكتروني للتلميذ",
  "Student List": "قائمة التلاميذ",
  "Download List": "تنزيل القائمة",
  "Import Students": "استيراد التلاميذ",
  "Export Students": "تصدير التلاميذ",
  "Download Template": "تنزيل النموذج",
  "Upload Excel File": "رفع ملف إكسل",
  "Excel File": "ملف إكسل",
  "Import from Excel": "استيراد من إكسل",
  "Import Students from Excel": "استيراد التلاميذ من ملف إكسل",
  "Upload an Excel file with columns \"Prénom\" and \"Nom\" to create student accounts.": "ارفع ملف إكسل يحتوي على العمودين \"Prénom\" و \"Nom\" لإنشاء حسابات التلاميذ.",
  "Student Management": "إدارة التلاميذ",
  "Import students from Excel and manage student credentials": "استيراد التلاميذ من ملف إكسل وإدارة بيانات دخولهم",
  "Search students...": "البحث عن التلاميذ...",
  "Manage students in this class": "إدارة التلاميذ في هذا القسم",
  "Import students using Excel to get started.": "استيراد التلاميذ باستخدام إكسل للبدء.",
  "Import students using Excel to get started": "استيراد التلاميذ باستخدام إكسل للبدء",
  "No Students Found": "لم يتم العثور على تلاميذ",
  "No students match your search.": "لا يوجد تلاميذ يطابقون بحثك.",
  "Loading students...": "جاري تحميل التلاميذ...",
  "Export Activities": "تصدير الأنشطة",
  "Activity Timeline": "سجل الأنشطة",
  "Last Active": "آخر نشاط",
  "Joined": "تاريخ الانضمام",
  "Total Students": "إجمالي التلاميذ",
  "Active Students": "التلاميذ النشطون",
  "Remove Student": "إزالة التلميذ",
  "Student Details": "تفاصيل التلميذ",
  "Student Information": "معلومات التلميذ",
  "Password Reset Requests": "طلبات إعادة تعيين كلمة المرور",
  "Reset Student Password": "إعادة تعيين كلمة مرور التلميذ",
  "Temporary password:": "كلمة المرور المؤقتة:",
  "Manage your students and their enrollment": "إدارة تلاميذك وتسجيلهم",
  "View your classmates and course information": "عرض زملائك ومعلومات الدرس",
  "No students found": "لم يتم العثور على تلاميذ",
  "Add Your First Student": "أضف أول تلميذ لك",
  "Reports & Analytics": "التقارير والتحليلات",
  "Comprehensive insights into student performance and engagement": "رؤى شاملة حول أداء التلاميذ ومشاركتهم",
  "Daily activity and engagement metrics": "مقاييس النشاط والتفاعل اليومية",
  "Detailed performance metrics for all students": "مقاييس أداء مفصلة لجميع التلاميذ",
  "Export Report": "تصدير التقرير",
  "Export": "تصدير",
  "Overview": "نظرة عامة",
  "Activity": "النشاط",
  "Total Courses": "إجمالي الدروس",
  "Total Exams": "إجمالي الامتحانات",
  "Overall average": "المعدل العام",
  "Performance Distribution": "توزيع الأداء",
  "Student performance by score ranges": "أداء التلاميذ حسب فئات الدرجات",
  "Weekly Activity": "النشاط الأسبوعي",
  "Student engagement over the last 7 days": "تفاعل التلاميذ خلال آخر 7 أيام",
  "Select a room to view reports": "اختر غرفة لعرض التقارير",
  "Manage your account settings and preferences": "إدارة إعدادات وتفضيلات حسابك",
  "Personal Information": "المعلومات الشخصية",
  "Update your personal details and account information": "تحديث بياناتك الشخصية ومعلومات حسابك",
  "Email Address": "عنوان البريد الإلكتروني",
  "Email cannot be changed. Contact support if you need to update it.": "لا يمكن تغيير البريد الإلكتروني. اتصل بالدعم إذا كنت بحاجة لتحديثه.",
  "Edit Profile": "تعديل الملف الشخصي",
  "Profile Picture": "الصورة الشخصية",
  "Upload a profile picture to personalize your account": "ارفع صورة شخصية لتخصيص حسابك",
  "JPG, PNG or GIF. Max 5MB.": "JPG أو PNG أو GIF. بحد أقصى 5 ميجابايت.",
  "Security": "الأمان",
  "Manage your account security settings": "إدارة إعدادات أمان حسابك",
  "Reset your password via email": "إعادة تعيين كلمة المرور عبر البريد الإلكتروني",
  "Reset": "إعادة تعيين",
  "Two-Factor Authentication": "المصادقة الثنائية",
  "Coming soon: Add an extra layer of security": "قريباً: إضافة طبقة أمان إضافية",
  "Choose your preferred theme appearance": "اختر مظهر السمة المفضل لديك",
  "Select theme": "اختر المظهر",
  "Light": "فاتح",
  "Dark": "داكن",
  "System": "النظام",
  "Choose your preferred language": "اختر لغتك المفضلة",
  "Choisissez votre langue préférée": "اختر لغتك المفضلة",
  "Password & Security": "كلمة المرور والأمان",
  "Change your temporary password or request a password reset from your professor": "قم بتغيير كلمة المرور المؤقتة أو اطلب إعادة تعيين كلمة المرور من أستاذك",
  "Manage your account password": "إدارة كلمة مرور حسابك",
  "Change Password": "تغيير كلمة المرور",
  "Request Password Reset from Professor": "طلب إعادة تعيين كلمة المرور من الأستاذ",
  "Requesting...": "جاري الطلب...",
  "Note: Click the button above to send a reset request to your professor. They will provide you with a new temporary password.": "ملاحظة: انقر فوق الزر أعلاه لإرسال طلب إعادة تعيين إلى أستاذك. سيقوم بتزويدك بكلمة مرور مؤقتة جديدة.",
  "Manage your notification preferences": "إدارة تفضيلات الإشعارات الخاصة بك",
  "Gérer vos préférences de notification": "إدارة تفضيلات الإشعارات الخاصة بك",
  "Push Notifications": "إشعارات فورية",
  "Notifications Push": "إشعارات فورية",
  "Receive notifications about updates and activity.": "تلقي إشعارات حول التحديثات والأنشطة.",
  "Recevez des notifications concernant les mises à jour et l'activité.": "تلقي إشعارات حول التحديثات والأنشطة.",
  "Email Updates": "تحديثات البريد الإلكتروني",
  "Mises à jour par email": "تحديثات البريد الإلكتروني",
  "Receive email notifications about your account.": "تلقي إشعارات عبر البريد الإلكتروني حول حسابك.",
  "Recevez des notifications par email concernant votre compte.": "تلقي إشعارات عبر البريد الإلكتروني حول حسابك.",
  "Activities exported successfully": "تم تصدير الأنشطة بنجاح",
  "An account with this email already exists": "يوجد حساب مسجل بهذا البريد الإلكتروني بالفعل",
  "Class and all related data deleted successfully!": "تم حذف القسم وجميع البيانات المرتبطة به بنجاح!",
  "Class updated successfully!": "تم تحديث القسم بنجاح!",
  "Course added successfully": "تمت إضافة الدرس بنجاح",
  "Course and all related data deleted successfully": "تم حذف الدرس وجميع البيانات المرتبطة به بنجاح",
  "Course materials uploaded successfully": "تم رفع مواد الدرس بنجاح",
  "Course title is required": "عنوان الدرس مطلوب",
  "Course updated successfully": "تم تحديث الدرس بنجاح",
  "Email not confirmed. Please enter the verification code.": "البريد الإلكتروني غير مؤكد. يرجى إدخال رمز التحقق.",
  "Email verified successfully! Welcome to Course Harmony.": "تم التحقق من البريد الإلكتروني بنجاح! مرحباً بك في تناغم الدروس.",
  "Exam added successfully": "تمت إضافة الامتحان بنجاح",
  "Exam deleted successfully": "تم حذف الامتحان بنجاح",
  "Exam updated successfully": "تم تحديث الامتحان بنجاح",
  "Exercise added successfully": "تمت إضافة التمرين بنجاح",
  "Exercise deleted successfully": "تم حذف التمرين بنجاح",
  "Exercise updated successfully": "تم تحديث التمرين بنجاح",
  "Failed to add course": "فشل في إضافة الدرس",
  "Failed to add exam": "فشل في إضافة الامتحان",
  "Failed to add exercise": "فشل في إضافة التمرين",
  "Failed to add option": "فشل في إضافة الخيار",
  "Failed to add question": "فشل في إضافة السؤال",
  "Failed to add room": "فشل في إضافة الغرفة",
  "Failed to add student": "فشل في إضافة التلميذ",
  "Failed to copy to clipboard": "فشل في النسخ إلى الحافظة",
  "Failed to create course": "فشل في إنشاء الدرس",
  "Failed to delete class": "فشل في حذف القسم",
  "Failed to delete course": "فشل في حذف الدرس",
  "Failed to delete course exams": "فشل في حذف امتحانات الدرس",
  "Failed to delete course exercises": "فشل في حذف تمارين الدرس",
  "Failed to delete exam": "فشل في حذف الامتحان",
  "Failed to delete exercise": "فشل في حذف التمرين",
  "Failed to delete question": "فشل في حذف السؤال",
  "Failed to delete room": "فشل في حذف الغرفة",
  "Failed to download PDF": "فشل في تنزيل ملف PDF",
  "Failed to download student list": "فشل في تنزيل قائمة التلاميذ",
  "Failed to enroll student": "فشل في تسجيل التلميذ",
  "Failed to export activities": "فشل في تصدير الأنشطة",
  "Failed to import students": "فشل في استيراد التلاميذ",
  "Failed to import students from Excel file": "فشل في استيراد التلاميذ من ملف الإكسل",
  "Failed to load activities": "فشل في تحميل الأنشطة",
  "Failed to load password reset requests": "فشل في تحميل طلبات إعادة تعيين كلمة المرور",
  "Failed to load reports": "فشل في تحميل التقارير",
  "Failed to load rooms": "فشل في تحميل الغرف",
  "Failed to load sessions": "فشل في تحميل الجلسات",
  "Failed to load student details for export": "فشل في تحميل تفاصيل التلاميذ للتصدير",
  "Failed to load student profiles": "فشل في تحميل ملفات تعريف التلاميذ",
  "Failed to load students": "فشل في تحميل التلاميذ",
  "Failed to open PDF": "فشل في فتح ملف PDF",
  "Failed to remove enrollment": "فشل في إلغاء التسجيل",
  "Failed to remove file": "فشل في إزالة الملف",
  "Failed to remove student": "فشل في إزالة التلميذ",
  "Failed to request password reset": "فشل في طلب إعادة تعيين كلمة المرور",
  "Failed to reset student password": "فشل في إعادة تعيين كلمة مرور التلميذ",
  "Failed to save answers": "فشل في حفظ الإجابات",
  "Failed to send reset email": "فشل في إرسال بريد إعادة التعيين",
  "Failed to submit quiz": "فشل في تسليم الاختبار",
  "Failed to unenroll student": "فشل في إلغاء تسجيل التلميذ",
  "Failed to update class": "فشل في تحديث القسم",
  "Failed to update course": "فشل في تحديث الدرس",
  "Failed to update exam": "فشل في تحديث الامتحان",
  "Failed to update exercise": "فشل في تحديث التمرين",
  "Failed to update profile": "فشل في تحديث الملف الشخصي",
  "Failed to update question": "فشل في تحديث السؤال",
  "Failed to update request status": "فشل في تحديث حالة الطلب",
  "Failed to update room": "فشل في تحديث الغرفة",
  "Failed to upload PDF": "فشل في رفع ملف PDF",
  "Failed to upload avatar": "فشل في رفع الصورة الشخصية",
  "File removed successfully": "تمت إزالة الملف بنجاح",
  "Image added to question": "تمت إضافة الصورة إلى السؤال",
  "Image size must be less than 5MB": "يجب أن يكون حجم الصورة أقل من 5 ميجابايت",
  "Invalid email or password": "البريد الإلكتروني أو كلمة المرور غير صحيحة",
  "Invalid username or password": "رمز مسار أو كلمة المرور غير صحيحة",
  "Link added to question": "تمت إضافة الرابط إلى السؤال",
  "Login failed": "فشل تسجيل الدخول",
  "Login failed. Please contact your professor.": "فشل تسجيل الدخول. يرجى الاتصال بأستاذك.",
  "Logout failed": "فشل تسجيل الخروج",
  "No activities to export": "لا توجد أنشطة لتصديرها",
  "No students to download. Add students first.": "لا يوجد تلاميذ لتنزيلهم. أضف تلاميذ أولاً.",
  "No valid student data found in the Excel file": "لم يتم العثور على بيانات تلاميذ صالحة في ملف الإكسل",
  "Only PDF files are allowed": "يُسمح فقط بملفات PDF",
  "Only professors can add courses": "يمكن للأساتذة فقط إضافة دروس",
  "Only professors can add rooms": "يمكن للأساتذة فقط إضافة غرف",
  "PDF file removed": "تمت إزالة ملف PDF",
  "PDF file selected successfully": "تم اختيار ملف PDF بنجاح",
  "PDF uploaded successfully": "تم رفع ملف PDF بنجاح",
  "Password reset email sent! Please check your inbox.": "تم إرسال بريد إعادة تعيين كلمة المرور! يرجى التحقق من بريدك الوارد.",
  "Password reset request sent to your professor": "تم إرسال طلب إعادة تعيين كلمة المرور إلى أستاذك",
  "Please add at least 2 options": "يرجى إضافة خيارين على الأقل",
  "Please enter a question": "يرجى إدخال سؤال",
  "Please fill in all fields": "يرجى ملء جميع الحقول",
  "Please mark at least one correct answer": "يرجى تحديد إجابة صحيحة واحدة على الأقل",
  "Please select a PDF file": "يرجى اختيار ملف PDF",
  "Please select an Excel file (.xlsx or .xls)": "يرجى اختيار ملف إكسل (.xlsx أو .xls)",
  "Please select an image file": "يرجى اختيار ملف صورة",
  "Profile updated successfully": "تم تحديث الملف الشخصي بنجاح",
  "Question added successfully": "تمت إضافة السؤال بنجاح",
  "Question deleted": "تم حذف السؤال",
  "Question deleted successfully": "تم حذف السؤال بنجاح",
  "Question updated successfully": "تم تحديث السؤال بنجاح",
  "Quiz submitted successfully": "تم تسليم الاختبار بنجاح",
  "Quiz submitted successfully!": "تم تسليم الاختبار بنجاح!",
  "Registration failed": "فشل إنشاء الحساب",
  "Registration successful! A verification code has been sent to your email.": "تم إنشاء الحساب بنجاح! تم إرسال رمز التحقق إلى بريدك الإلكتروني.",
  "Report exported successfully": "تم تصدير التقرير بنجاح",
  "Room added successfully": "تمت إضافة الغرفة بنجاح",
  "Room deleted successfully": "تم حذف الغرفة بنجاح",
  "Room updated successfully": "تم تحديث الغرفة بنجاح",
  "Student added successfully! They will receive an email to verify their account.": "تمت إضافة التلميذ بنجاح! سيتلقى بريداً إلكترونياً للتحقق من حسابه.",
  "Student enrolled successfully": "تم تسجيل التلميذ بنجاح",
  "Student is already enrolled in this course": "التلميذ مسجل بالفعل في هذا الدرس",
  "Student list downloaded successfully": "تم تنزيل قائمة التلاميذ بنجاح",
  "Student password reset successfully": "تمت إعادة تعيين كلمة مرور التلميذ بنجاح",
  "Student removed from course": "تمت إزالة التلميذ من الدرس",
  "Student removed from course successfully": "تمت إزالة التلميذ من الدرس بنجاح",
  "Student removed successfully": "تمت إزالة التلميذ بنجاح",
  "Student unenrolled successfully": "تم إلغاء تسجيل التلميذ بنجاح",
  "Unable to find your professor. Please contact support.": "تعذر العثور على أستاذك. يرجى التواصل مع الدعم الفني.",
  "Verification code resent! Please check your inbox.": "تمت إعادة إرسال رمز التحقق! يرجى التحقق من صندوق الوارد.",
  "You have been logged out": "تم تسجيل خروجك بنجاح"
};

const MONTHS: Record<string, string> = {
  "Jan": "يناير",
  "Feb": "فبراير",
  "Mar": "مارس",
  "Apr": "أبريل",
  "May": "مايو",
  "Jun": "يونيو",
  "Jul": "يوليو",
  "Aug": "أغسطس",
  "Sep": "سبتمبر",
  "Oct": "أكتوبر",
  "Nov": "نوفمبر",
  "Dec": "ديسمبر"
};

// Regex-based dynamic pattern matchers for Arabic
const DYNAMIC_PATTERNS: Array<{ pattern: RegExp; replacer: (...args: any[]) => string }> = [
  {
    // "Manage and view courses in TCSFR1"
    pattern: /^Manage and view courses in\s+(.+)$/i,
    replacer: (_match, room) => `إدارة وعرض الدروس في ${room}`,
  },
  {
    // "There are no courses in TCSFR1 yet. Add your first course to get started."
    pattern: /^There are no courses in\s+(.+?)\s+yet\.\s*Add your first course to get started\.?$/i,
    replacer: (_match, room) => `لا توجد دروس في ${room} بعد. أضف درسك الأول للبدء.`,
  },
  {
    // "You are not enrolled in any courses in TCSFR1."
    pattern: /^You are not enrolled in any courses in\s+(.+?)\.?$/i,
    replacer: (_match, room) => `أنت غير مسجل في أي دروس في ${room}.`,
  },
  {
    // "Create a new course in TCSFR1."
    pattern: /^Create a new course in\s+(.+?)\.?$/i,
    replacer: (_match, room) => `إنشاء درس جديد في ${room}.`,
  },
  {
    // "Manage and view exercises in TCSFR1"
    pattern: /^Manage and view exercises in\s+(.+)$/i,
    replacer: (_match, room) => `إدارة وعرض التمارين في ${room}`,
  },
  {
    // "No exercises have been created in TCSFR1 yet..."
    pattern: /^No exercises have been created in\s+(.+?)\s+yet.*?$/i,
    replacer: (_match, room) => `لم يتم إنشاء أي تمارين في ${room} بعد.`,
  },
  {
    // "Manage exams and tests in TCSFR1"
    pattern: /^Manage exams and tests in\s+(.+)$/i,
    replacer: (_match, room) => `إدارة الامتحانات والاختبارات في ${room}`,
  },
  {
    // "Manage students in TCSFR1"
    pattern: /^Manage students in\s+(.+)$/i,
    replacer: (_match, room) => `إدارة التلاميذ في ${room}`,
  },
  {
    // "Schedule Exam for TCSFR1"
    pattern: /^Schedule Exam for\s+(.+)$/i,
    replacer: (_match, course) => `جدولة امتحان لـ ${course}`,
  },
  {
    // "You haven't scheduled any exams for TCSFR1 yet."
    pattern: /^You haven't scheduled any exams for\s+(.+?)\s+yet\.?$/i,
    replacer: (_match, course) => `لم تقم بجدولة أي امتحانات لـ ${course} بعد.`,
  },
  {
    // "No exams are currently scheduled for TCSFR1."
    pattern: /^No exams are currently scheduled for\s+(.+?)\.?$/i,
    replacer: (_match, course) => `لا توجد امتحانات مجدولة حالياً لـ ${course}.`,
  },
  {
    // "Showing X exam(s) [for course]"
    pattern: /^Showing\s+(\d+)\s+(?:exam|exams|الامتحانات|امتحانات)(?:\s+for\s+(.+))?$/i,
    replacer: (_match, count, course) => course ? `عرض ${count} من الامتحانات لـ ${course}` : `عرض ${count} من الامتحانات`,
  },
  {
    // "Showing X course(s)"
    pattern: /^Showing\s+(\d+)\s+(?:course|courses|الدروس|دروس)$/i,
    replacer: (_match, count) => `عرض ${count} من الدروس`,
  },
  {
    // "Showing X exercise(s)"
    pattern: /^Showing\s+(\d+)\s+(?:exercise|exercises|التمارين|تمارين)$/i,
    replacer: (_match, count) => `عرض ${count} من التمارين`,
  },
  {
    // "Showing X student(s)"
    pattern: /^Showing\s+(\d+)\s+(?:student|students|التلاميذ|تلاميذ)$/i,
    replacer: (_match, count) => `عرض ${count} من التلاميذ`,
  },
  {
    // "0 طالبs" or "X student(s)"
    pattern: /^(\d+)\s+(?:student|students|طالبs|طالب|طلاب|تلميذ|تلاميذ)$/i,
    replacer: (_match, count) => `${count} تلاميذ`,
  },
  {
    // "X Courses" or "X الدورات"
    pattern: /^(\d+)\s+(?:course|courses|الدورات|دورات|الدروس|دروس)$/i,
    replacer: (_match, count) => `${count} دروس`,
  },
  {
    // "X Exercises" or "X التمارين"
    pattern: /^(\d+)\s+(?:exercise|exercises|التمارين|تمارين)$/i,
    replacer: (_match, count) => `${count} تمارين`,
  },
  {
    // "X Exams" or "X الامتحانات"
    pattern: /^(\d+)\s+(?:exam|exams|الامتحانات|امتحانات)$/i,
    replacer: (_match, count) => `${count} امتحانات`,
  },
  {
    // Month abbreviations: "Sep 12", "Oct 5"
    pattern: /^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d+)$/i,
    replacer: (_match, mon, day) => `${MONTHS[mon] || mon} ${day}`,
  },
  {
    // "${fieldName} copied to clipboard"
    pattern: /^(.+?)\s+copied to clipboard$/i,
    replacer: (_match, field) => `تم نسخ ${field} إلى الحافظة`,
  },
  {
    // "${file.name} is already selected"
    pattern: /^(.+?)\s+is already selected$/i,
    replacer: (_match, file) => `${file} محدد بالفعل`,
  },
  {
    // "${file.name} is larger than ${maxSizeMB}MB"
    pattern: /^(.+?)\s+is larger than\s+(\d+)\s*MB$/i,
    replacer: (_match, file, size) => `${file} أكبر من ${size} ميجابايت`,
  },
  {
    // "${file.name} is not a PDF file"
    pattern: /^(.+?)\s+is not a PDF file$/i,
    replacer: (_match, file) => `${file} ليس ملف PDF صالح`,
  },
  {
    // "Created X out of Y students. Some failed - check console for details."
    pattern: /^Created\s+(\d+)\s+out of\s+(\d+)\s+students.*?$/i,
    replacer: (_match, created, total) => `تم إنشاء ${created} من أصل ${total} تلميذ. بعض العمليات لم تكتمل.`,
  },
  {
    // "Successfully imported X students"
    pattern: /^Successfully imported\s+(\d+)\s+students$/i,
    replacer: (_match, count) => `تم استيراد ${count} تلميذ بنجاح`,
  },
  {
    // "Failed to create students: ..."
    pattern: /^Failed to create students:\s*(.*)$/i,
    replacer: (_match, details) => `فشل في إنشاء التلاميذ: ${details}`,
  },
  {
    // "Failed to remove student: ..."
    pattern: /^Failed to remove student:\s*(.*)$/i,
    replacer: (_match, details) => `فشل في إزالة التلميذ: ${details}`,
  },
  {
    // "Failed to save X info"
    pattern: /^Failed to save\s+(.+?)\s+info$/i,
    replacer: (_match, item) => `فشل في حفظ معلومات ${item}`,
  },
  {
    // "Failed to upload X"
    pattern: /^Failed to upload\s+(.+)$/i,
    replacer: (_match, item) => `فشل في رفع ${item}`,
  },
  {
    // "File size exceeds XMB limit"
    pattern: /^File size exceeds\s+(\d+)\s*MB limit$/i,
    replacer: (_match, size) => `يتجاوز حجم الملف الحد الأقصى (${size} ميجابايت)`,
  },
  {
    // "File size must be less than XMB"
    pattern: /^File size must be less than\s+(\d+)\s*MB$/i,
    replacer: (_match, size) => `يجب أن يكون حجم الملف أقل من ${size} ميجابايت`,
  },
  {
    // "Maximum X files allowed"
    pattern: /^Maximum\s+(\d+)\s+files allowed$/i,
    replacer: (_match, max) => `الحد الأقصى المسموح به هو ${max} ملفات`,
  },
  {
    // "Renvoyer le mail dans Xs"
    pattern: /^Renvoyer le mail dans\s+(\d+)s$/i,
    replacer: (_match, sec) => `إعادة إرسال البريد خلال ${sec} ثانية`,
  },
  {
    // "Due: ..."
    pattern: /^Due:\s*(.+)$/i,
    replacer: (_match, date) => `تاريخ الاستحقاق: ${date}`,
  },
  {
    // "Created: ..." or "Created ..."
    pattern: /^Created:?\s*(.+)$/i,
    replacer: (_match, date) => `تاريخ الإنشاء: ${date}`,
  },
  {
    // "Duration: Xmin" or "Duration: ..."
    pattern: /^Duration:\s*(.+)$/i,
    replacer: (_match, dur) => `المدة: ${dur}`,
  },
  {
    // "Xmin"
    pattern: /^(\d+)\s*min$/i,
    replacer: (_match, min) => `${min} دقيقة`,
  },
];


/**
 * Translates any English, French or non-Moroccan terminology text to Modern Standard Arabic.
 */
function translateToArabicUncached(text: string): string {
  if (!text || typeof text !== "string") return text;

  const trimmed = text.trim();
  if (!trimmed) return text;

  // 1. Direct dictionary match
  if (ARABIC_DICTIONARY[trimmed]) {
    return ARABIC_DICTIONARY[trimmed];
  }

  // 2. Case-insensitive dictionary match
  const lowerHit = lowerDictionary().get(trimmed.toLowerCase());
  if (lowerHit !== undefined) {
    return lowerHit;
  }

  // 3. Dynamic regex pattern match
  for (const item of DYNAMIC_PATTERNS) {
    if (item.pattern.test(trimmed)) {
      return trimmed.replace(item.pattern, item.replacer);
    }
  }

  // 4. Moroccan terminology cleanup if old terms are present
  if (
    trimmed.includes("الدورات") ||
    trimmed.includes("الطلاب") ||
    trimmed.includes("الفصول") ||
    trimmed.includes("طالبs")
  ) {
    return trimmed
      .replace(/الدورات/g, "الدروس")
      .replace(/دورة/g, "درس")
      .replace(/دورات/g, "دروس")
      .replace(/الطلاب/g, "التلاميذ")
      .replace(/طالبs/g, "تلاميذ")
      .replace(/طالب/g, "تلميذ")
      .replace(/طلاب/g, "تلاميذ")
      .replace(/الفصول/g, "الأقسام")
      .replace(/فصول/g, "أقسام");
  }

  return text;
}

// Dictionnaire en minuscules construit une seule fois (au lieu de parcourir tout le
// dictionnaire à chaque texte), et cache des résultats (y compris « pas de traduction »).
let LOWER_DICT: Map<string, string> | null = null;
function lowerDictionary(): Map<string, string> {
  if (!LOWER_DICT) {
    LOWER_DICT = new Map<string, string>();
    const keys = Object.keys(ARABIC_DICTIONARY);
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i].toLowerCase();
      if (!LOWER_DICT.has(k)) LOWER_DICT.set(k, ARABIC_DICTIONARY[keys[i]]);
    }
  }
  return LOWER_DICT;
}

const RESULT_CACHE = new Map<string, string>();
const RESULT_CACHE_MAX = 5000;

export function translateToArabic(text: string): string {
  if (!text || typeof text !== "string") return text;
  const hit = RESULT_CACHE.get(text);
  if (hit !== undefined) return hit;
  const out = translateToArabicUncached(text);
  if (RESULT_CACHE.size >= RESULT_CACHE_MAX) RESULT_CACHE.clear();
  RESULT_CACHE.set(text, out);
  return out;
}
