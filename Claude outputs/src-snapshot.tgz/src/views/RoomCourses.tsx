import { accessStore } from "@/contexts/AccessContext";
import { useEffect, useRef, useState } from "react";
import { useParams, Navigate } from "@/lib/router";
import { useAuth, UserProfile } from "@/contexts/AuthContext";
import { useCourses, Course, Room } from "@/contexts/CourseContext";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter,
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { 
  BookOpen, 
  Eye, 
  EyeOff, 
  Edit, 
  Trash, 
  Plus,
  Loader2,
  FileText,
  Copy
} from "lucide-react";
import { CopyToDialog, type CopySource } from "@/components/CopyToDialog";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import MultiPdfUpload from "@/components/MultiPdfUpload";
import CourseMaterials from "@/components/CourseMaterials";
import { CourseCover, CourseViewerDialog } from "@/components/CourseMediaGallery";
import { saveCourseMaterials, deleteCourseMaterial } from "@/lib/courseMedia";
import type { VideoLinkDraft } from "@/components/MultiPdfUpload";
import { useLanguage } from "@/contexts/LanguageContext";
import ViewToggle from "@/components/ViewToggle";
import { PublishToLibraryButton } from "@/components/library/LibraryShared";
import { CourseOrderDialog, PublishAtField, savePublishAt, toLocalInput } from "@/components/courses/CourseScheduling";

interface CourseMaterial {
  id: string;
  file_name: string;
  file_path: string;
  file_size?: number;
  uploaded_at: string;
}

const RoomCourses = () => {
  const { roomId } = useParams();
  const { user } = useAuth();
  const { t, language } = useLanguage();
  const { 
    rooms, 
    courses, 
    refreshData, 
    addCourse, 
    updateCourse, 
    deleteCourse, 
    toggleCourseVisibility 
  } = useCourses();
  
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [copySource, setCopySource] = useState<CopySource | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [isVisible, setIsVisible] = useState(true);
  const [publishAt, setPublishAt] = useState("");
  const [orderOpen, setOrderOpen] = useState(false);
  const [currentCourse, setCurrentCourse] = useState<Course | null>(null);
  const [courseToDelete, setCourseToDelete] = useState<Course | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [videoLinks, setVideoLinks] = useState<VideoLinkDraft[]>([]);
  const [uploadProgress, setUploadProgress] = useState<{ done: number; total: number } | null>(null);
  const [viewerCourse, setViewerCourse] = useState<Course | null>(null);
  const roomCoursesRef = useRef<Course[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  // Verrou synchrone : bloque les doubles / triples clics avant même le re-rendu
  const submitLockRef = useRef(false);
  const [courseMaterials, setCourseMaterials] = useState<Record<string, CourseMaterial[]>>({});
  const [existingFiles, setExistingFiles] = useState<CourseMaterial[]>([]);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [deletingCourse, setDeletingCourse] = useState(false);
  const tr = (fr: string, ar: string, en: string) => (language === "ar" ? ar : language === "fr" ? fr : en);
  const dateLocale = language === "ar" ? "ar-MA" : language === "fr" ? "fr-FR" : "en-GB";
  
  const isProfessor = user?.role === "professor";
  
  // Load room-specific data when component mounts
  useEffect(() => {
    if (user && roomId) {
      refreshData(roomId);
    }
    // Dépendances stables : uniquement l'utilisateur et la classe (le contexte déduplique)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, roomId]);

  // Redirect if no roomId
  if (!roomId) {
    return <Navigate to="/dashboard" replace />;
  }
  
  // Get current room
  const currentRoom = rooms.find(room => room.id === roomId);
  
  // Filter courses for current room
  const roomCourses = courses.filter(course => course.room_id === roomId);
  roomCoursesRef.current = roomCourses;

  // Load course materials
  const loadCourseMaterials = async (extraCourseId?: string) => {
    try {
      // Toujours la liste la plus récente (évite une closure périmée juste après une création)
      const courseIds = Array.from(new Set([...roomCoursesRef.current.map(course => course.id), ...(extraCourseId ? [extraCourseId] : [])]));
      if (courseIds.length === 0) return;
      const { data: materials, error } = await supabase
        .from('course_materials')
        .select('*')
        .in('course_id', courseIds)
        .order('uploaded_at', { ascending: true });

      if (error) throw error;

      // Group materials by course_id
      const materialsByCode: Record<string, CourseMaterial[]> = {};
      materials?.forEach((material) => {
        if (!materialsByCode[material.course_id]) {
          materialsByCode[material.course_id] = [];
        }
        materialsByCode[material.course_id].push(material);
      });

      setCourseMaterials(materialsByCode);
    } catch (error) {
      console.error('Error loading course materials:', error);
    }
  };

  // Load course materials when room courses change
  // (dépendance = liste des ids : évite un rechargement à chaque rendu)
  const roomCourseIdsKey = roomCourses.map(c => c.id).join(',');
  useEffect(() => {
    if (roomCourses.length > 0) {
      loadCourseMaterials();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roomCourseIdsKey]);

  // Load specific course materials
  const loadCourseSpecificMaterials = async (courseId: string) => {
    try {
      const { data: materials, error } = await supabase
        .from('course_materials')
        .select('*')
        .eq('course_id', courseId)
        .order('uploaded_at', { ascending: true });

      if (error) throw error;
      return materials || [];
    } catch (error) {
      console.error('Error loading course materials:', error);
      return [];
    }
  };
  
  // Handle form submission
  const handleAddCourse = async () => {
    if (submitLockRef.current) return;
    if (!title.trim()) {
      toast.error(tr("Le titre du cours est obligatoire", "عنوان الدرس مطلوب", "Course title is required"));
      return;
    }

    submitLockRef.current = true;
    setIsSubmitting(true);
    try {
      const newCourse = await addCourse({
        title: title.trim(),
        description: description.trim(),
        room_id: roomId,
        is_visible: isVisible
      });

      if (newCourse && !isVisible && publishAt) await savePublishAt("courses", newCourse.id, publishAt);
      if (newCourse && (selectedFiles.length > 0 || videoLinks.length > 0)) {
        await uploadFiles(newCourse.id);
      }

      if (newCourse) {
        resetForm();
      }
    } finally {
      submitLockRef.current = false;
      setIsSubmitting(false);
    }
  };

  // Upload files (PDF, images, videos) + video links
  const uploadFiles = async (courseId: string) => {
    const { saved, failed } = await saveCourseMaterials({
      courseId,
      files: selectedFiles,
      links: videoLinks,
      userId: user?.id,
      onProgress: (done, total) => setUploadProgress({ done, total }),
    });
    setUploadProgress(null);
    await loadCourseMaterials(courseId);
    if (failed.length > 0) {
      toast.error((language === "ar" ? "تعذر رفع: " : language === "fr" ? "Échec du téléversement : " : "Upload failed: ") + failed.join(", "));
    }
    if (saved > 0) {
      toast.success(language === "ar" ? "تم رفع مواد الدرس" : language === "fr" ? "Supports du cours ajoutés" : "Course materials uploaded");
    }
  };

  // Reset form
  const resetForm = () => {
    setTitle("");
    setDescription("");
    setIsVisible(true);
    setPublishAt("");
    setSelectedFiles([]);
    setVideoLinks([]);
    setUploadProgress(null);
    setExistingFiles([]);
    setIsAddDialogOpen(false);
    setIsEditDialogOpen(false);
    setCurrentCourse(null);
  };
  
  // Handle edit submission
  const handleEditCourse = async () => {
    if (!currentCourse || submitLockRef.current) return;
    
    if (!title.trim()) {
      toast.error(tr("Le titre du cours est obligatoire", "عنوان الدرس مطلوب", "Course title is required"));
      return;
    }

    submitLockRef.current = true;
    setIsSubmitting(true);
    try {
      const success = await updateCourse(currentCourse.id, {
        title: title.trim(),
        description: description.trim(),
        is_visible: isVisible
      });

      if (success && (currentCourse.publish_at || publishAt)) {
        await savePublishAt("courses", currentCourse.id, isVisible ? "" : publishAt);
        refreshData(roomId, { force: true });
      }
      // Upload new files if any
      if (success && (selectedFiles.length > 0 || videoLinks.length > 0)) {
        await uploadFiles(currentCourse.id);
      }

      if (success) {
        resetForm();
      }
    } finally {
      submitLockRef.current = false;
      setIsSubmitting(false);
    }
  };
  
  // Handle delete - open confirmation dialog
  const handleDeleteCourse = (course: Course) => {
    setCourseToDelete(course);
  };

  const confirmDeleteCourse = async () => {
    if (!courseToDelete || deletingCourse) return;
    setDeletingCourse(true);
    try {
      const success = await deleteCourse(courseToDelete.id);
      if (success) {
        setCourseToDelete(null);
        refreshData(roomId);
      }
    } finally {
      setDeletingCourse(false);
    }
  };
  
  // Open edit dialog
  const openEditDialog = async (course: Course) => {
    setCurrentCourse(course);
    setTitle(course.title);
    setDescription(course.description || "");
    setIsVisible(course.is_visible);
    setPublishAt(toLocalInput(course.publish_at));
    
    // Load existing materials for this course
    const materials = await loadCourseSpecificMaterials(course.id);
    setExistingFiles(materials);
    
    setIsEditDialogOpen(true);
  };

  // Remove existing file (row + storage object)
  const removeExistingFile = async (fileId: string) => {
    const material = existingFiles.find(f => f.id === fileId);
    if (!material) return;
    const ok = await deleteCourseMaterial(material);
    if (ok) {
      setExistingFiles(prev => prev.filter(file => file.id !== fileId));
      loadCourseMaterials();
      toast.success(language === "ar" ? "تم حذف المادة" : language === "fr" ? "Support supprimé" : "Material removed");
    } else {
      toast.error(language === "ar" ? "تعذر الحذف" : language === "fr" ? "Suppression impossible" : "Could not remove");
    }
  };
  
  if (!currentRoom) {
    return (
      <div className="space-y-6 animate-fade-in">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">
              {tr("Classe introuvable.", "القسم غير موجود.", "Class not found.")}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{t("nav.courses")}</h1>
          <p className="text-muted-foreground text-xs sm:text-sm mt-1">
            {language === "ar" ? `إدارة وعرض الدروس في ${currentRoom.name}` : language === "fr" ? `Gérer et consulter les cours dans ${currentRoom.name}` : `Manage and view courses in ${currentRoom.name}`}
          </p>
        </div>
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap sm:flex-nowrap">
          {/* View Toggle */}
          <ViewToggle view={viewMode === 'grid' ? 'grid' : 'table'} onViewChange={(v) => setViewMode(v === 'grid' ? 'grid' : 'list')} />
          {isProfessor && roomCourses.length > 1 && (
            <>
              <Button variant="outline" className="text-xs sm:text-sm" onClick={() => { if (accessStore.guard("course.schedule")) setOrderOpen(true); }}>{tr("Réordonner", "إعادة الترتيب", "Reorder")}</Button>
              <CourseOrderDialog open={orderOpen} onOpenChange={setOrderOpen} roomId={roomId!} courses={roomCourses} tr={tr} onSaved={() => refreshData(roomId, { force: true })} />
            </>
          )}
          
          {isProfessor && (
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="shadow-elegant text-xs sm:text-sm">
                  <Plus className="h-4 w-4" />
                  {t("Add Course")}
                </Button>
              </DialogTrigger>
              <DialogContent className="w-[95vw] max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{t("Add New Course")}</DialogTitle>
                  <DialogDescription>
                    {language === "ar" ? `إنشاء درس جديد في ${currentRoom.name}.` : language === "fr" ? `Créer un nouveau cours dans ${currentRoom.name}.` : `Create a new course in ${currentRoom.name}.`}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">{language === "ar" ? "عنوان الدرس *" : language === "fr" ? "Titre du cours *" : "Course Title *"}</Label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder={language === "ar" ? "مثال: الرياضيات المتقدمة" : language === "fr" ? "ex. : Introduction à l'informatique" : "e.g., Introduction to Computer Science"}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">{language === "ar" ? "وصف الدرس" : language === "fr" ? "Description du cours" : "Course Description"}</Label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder={language === "ar" ? "قدم وصفاً مفصلاً للمحتوى وأهداف الدرس..." : language === "fr" ? "Fournissez une description détaillée du contenu du cours, des objectifs et de ce que les élèves apprendront..." : "Provide a detailed description of the course content, objectives, and what students will learn..."}
                      rows={4}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{language === "ar" ? "مواد الدرس (PDF، صور، فيديوهات)" : language === "fr" ? "Supports de cours (PDF, images, vidéos)" : "Course materials (PDF, images, videos)"}</Label>
                    <MultiPdfUpload
                      selectedFiles={selectedFiles}
                      onFilesChange={setSelectedFiles}
                      videoLinks={videoLinks}
                      onVideoLinksChange={setVideoLinks}
                      maxFiles={20}
                      maxSizeMB={50}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="visible"
                      checked={isVisible}
                      onCheckedChange={setIsVisible}
                    />
                    <Label htmlFor="visible">{language === "ar" ? "جعل الدرس مرئياً للتلاميذ" : language === "fr" ? "Rendre le cours visible pour les élèves" : "Make course visible to students"}</Label>
                  </div>
                  {!isVisible && <PublishAtField id="publish-at" value={publishAt} onChange={setPublishAt} tr={tr} />}
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={resetForm}>
                    {language === "ar" ? "إلغاء" : language === "fr" ? "Annuler" : "Cancel"}
                  </Button>
                  <Button onClick={handleAddCourse} disabled={isSubmitting || !title.trim()}>
                    {isSubmitting
                      ? (uploadProgress && uploadProgress.total > 0 ? `${language === "ar" ? "رفع" : language === "fr" ? "Téléversement" : "Uploading"} ${Math.min(uploadProgress.done + 1, uploadProgress.total)}/${uploadProgress.total}…` : (language === "ar" ? "جارٍ الإنشاء…" : language === "fr" ? "Création…" : "Creating…"))
                      : (language === "ar" ? "إنشاء الدرس" : language === "fr" ? "Créer le cours" : "Create Course")}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>
      
      {/* Courses Display */}
      {roomCourses.length > 0 ? (
        viewMode === 'grid' ? (
          // Grid View
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {roomCourses.map((course) => (
              <Card key={course.id} className="group card-hover overflow-hidden">
                <CourseCover
                  materials={courseMaterials[course.id] || []}
                  title={course.title}
                  onClick={() => setViewerCourse(course)}
                />
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-base line-clamp-2">
                        {course.title}
                      </CardTitle>
                      {course.description && (
                        <CardDescription className="mt-2 line-clamp-2">
                          {course.description}
                        </CardDescription>
                      )}
                    </div>
                    <Badge variant={course.is_visible ? "default" : "secondary"} className="shrink-0">
                      {course.is_visible ? tr("Visible", "مرئي", "Visible") : course.publish_at ? tr(`Le ${new Date(course.publish_at).toLocaleDateString(dateLocale)}`, `في ${new Date(course.publish_at).toLocaleDateString(dateLocale)}`, `On ${new Date(course.publish_at).toLocaleDateString(dateLocale)}`) : tr("Masqué", "مخفي", "Hidden")}
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <FileText className="h-4 w-4" />
                    <span>{language === "ar" ? "أُنشئ في " : language === "fr" ? "Créé le " : "Created "}{new Date(course.created_at).toLocaleDateString(dateLocale)}</span>
                  </div>
                  
                  {courseMaterials[course.id] && courseMaterials[course.id].length > 0 && (
                    <div className="pt-2 border-t">
                      <CourseMaterials 
                        materials={courseMaterials[course.id]} 
                        compact={true}
                        title={course.title}
                        description={course.description}
                      />
                    </div>
                  )}
                </CardContent>
                
                {isProfessor && (
                  <CardFooter className="pt-3 flex gap-2 border-t bg-muted/30">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toggleCourseVisibility(course.id)}
                      className="flex-1"
                    >
                      {course.is_visible ? (
                        <>
                          <EyeOff className="h-4 w-4" />
                          {tr("Masquer", "إخفاء", "Hide")}
                        </>
                      ) : (
                        <>
                          <Eye className="h-4 w-4" />
                          {tr("Afficher", "إظهار", "Show")}
                        </>
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-9 w-9 [@media(pointer:coarse)]:h-10 [@media(pointer:coarse)]:w-10"
                      onClick={() => openEditDialog(course)}
                      aria-label={tr(`Modifier le cours ${course.title}`, `تعديل الدرس ${course.title}`, `Edit course ${course.title}`)}
                      title={tr("Modifier", "تعديل", "Edit")}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setCopySource({ kind: "course", id: course.id, title: course.title, parentId: course.room_id })}
                      className="h-9 w-9 [@media(pointer:coarse)]:h-10 [@media(pointer:coarse)]:w-10"
                      aria-label={tr(`Copier le cours ${course.title} vers une classe`, `نسخ الدرس ${course.title} إلى قسم`, `Copy course ${course.title} to a class`)}
                      title={tr("Copier vers une classe", "نسخ إلى قسم", "Copy to a class")}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleDeleteCourse(course)}
                      className="h-9 w-9 [@media(pointer:coarse)]:h-10 [@media(pointer:coarse)]:w-10 text-destructive hover:text-destructive"
                      aria-label={tr(`Supprimer le cours ${course.title}`, `حذف الدرس ${course.title}`, `Delete course ${course.title}`)}
                      title={tr("Supprimer", "حذف", "Delete")}
                    >
                      <Trash className="h-4 w-4" />
                    </Button>
                    <PublishToLibraryButton kind="course" sourceId={course.id} tr={tr} variant="outline" iconOnly />
                  </CardFooter>
                )}
              </Card>
            ))}
          </div>
        ) : (
          // List View
          <div className="space-y-4">
            {roomCourses.map((course) => (
              <Card key={course.id} className="group card-hover overflow-hidden">
                <div className="flex flex-col md:flex-row">
                  <div className="flex-1 p-6">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start gap-3 mb-2">
                          <div className="p-2 border bg-background rounded-lg shrink-0">
                            <BookOpen className="h-5 w-5 text-muted-foreground" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <button type="button" onClick={() => setViewerCourse(course)} className="text-start text-base font-semibold hover:underline">
                              {course.title}
                            </button>
                            <p className="text-sm text-muted-foreground mt-1">
                              {language === "ar" ? "أُنشئ في " : language === "fr" ? "Créé le " : "Created "}{new Date(course.created_at).toLocaleDateString(dateLocale)}
                            </p>
                          </div>
                          <Badge variant={course.is_visible ? "default" : "secondary"} className="shrink-0">
                            {course.is_visible ? tr("Visible", "مرئي", "Visible") : course.publish_at ? tr(`Le ${new Date(course.publish_at).toLocaleDateString(dateLocale)}`, `في ${new Date(course.publish_at).toLocaleDateString(dateLocale)}`, `On ${new Date(course.publish_at).toLocaleDateString(dateLocale)}`) : tr("Masqué", "مخفي", "Hidden")}
                          </Badge>
                        </div>
                        
                        {course.description && (
                          <p className="text-muted-foreground mt-3 leading-relaxed">
                            {course.description}
                          </p>
                        )}
                        
                        {courseMaterials[course.id] && courseMaterials[course.id].length > 0 && (
                          <div className="mt-4">
                            <CourseMaterials 
                              materials={courseMaterials[course.id]} 
                              compact={false}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {isProfessor && (
                    <div className="flex md:flex-col gap-2 p-4 border-t md:border-t-0 md:border-l rtl:md:border-l-0 rtl:md:border-r bg-muted/30 md:w-32 justify-center">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleCourseVisibility(course.id)}
                        className="flex-1 md:flex-none"
                        aria-label={course.is_visible ? tr(`Masquer le cours ${course.title}`, `إخفاء الدرس ${course.title}`, `Hide course ${course.title}`) : tr(`Afficher le cours ${course.title}`, `إظهار الدرس ${course.title}`, `Show course ${course.title}`)}
                        title={course.is_visible ? tr("Masquer", "إخفاء", "Hide") : tr("Afficher", "إظهار", "Show")}
                      >
                        {course.is_visible ? (
                          <>
                            <EyeOff className="h-4 w-4" />
                            <span className="md:hidden">{tr("Masquer", "إخفاء", "Hide")}</span>
                          </>
                        ) : (
                          <>
                            <Eye className="h-4 w-4" />
                            <span className="md:hidden">{tr("Afficher", "إظهار", "Show")}</span>
                          </>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditDialog(course)}
                        className="flex-1 md:flex-none"
                        aria-label={tr(`Modifier le cours ${course.title}`, `تعديل الدرس ${course.title}`, `Edit course ${course.title}`)}
                        title={tr("Modifier", "تعديل", "Edit")}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCopySource({ kind: "course", id: course.id, title: course.title, parentId: course.room_id })}
                        className="flex-1 md:flex-none"
                        aria-label={tr(`Copier le cours ${course.title} vers une classe`, `نسخ الدرس ${course.title} إلى قسم`, `Copy course ${course.title} to a class`)}
                        title={tr("Copier vers une classe", "نسخ إلى قسم", "Copy to a class")}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteCourse(course)}
                        className="flex-1 md:flex-none text-destructive hover:text-destructive"
                        aria-label={tr(`Supprimer le cours ${course.title}`, `حذف الدرس ${course.title}`, `Delete course ${course.title}`)}
                        title={tr("Supprimer", "حذف", "Delete")}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                      <PublishToLibraryButton kind="course" sourceId={course.id} tr={tr} variant="outline" iconOnly />
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )
      ) : (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="p-4 border bg-background rounded-full mb-4">
              <BookOpen className="h-12 w-12 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold mb-2">{language === "ar" ? "لم يتم العثور على دروس" : language === "fr" ? "Aucun cours trouvé" : "No courses found"}</h3>
            <p className="text-muted-foreground text-center max-w-md mb-6">
              {isProfessor 
                ? (language === "ar" 
                    ? `لا توجد دروس في ${currentRoom.name} بعد. أضف درسك الأول للبدء.` 
                    : language === "fr" 
                    ? `Il n'y a pas encore de cours dans ${currentRoom.name}. Ajoutez votre premier cours pour commencer.` 
                    : `There are no courses in ${currentRoom.name} yet. Add your first course to get started.`)
                : (language === "ar" 
                    ? `أنت غير مسجل في أي دروس في ${currentRoom.name}.` 
                    : language === "fr" 
                    ? `Vous n'êtes inscrit à aucun cours dans ${currentRoom.name}.` 
                    : `You are not enrolled in any courses in ${currentRoom.name}.`)}
            </p>
            {isProfessor && (
              <Button onClick={() => setIsAddDialogOpen(true)} className="shadow-elegant">
                <Plus className="h-4 w-4" />
                {language === "ar" ? "إضافة أول درس" : language === "fr" ? "Ajouter votre premier cours" : "Add Your First Course"}
              </Button>
            )}
          </CardContent>
        </Card>
      )}
      
      {/* Edit Course Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="w-[95vw] max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{language === "ar" ? "تعديل الدرس" : language === "fr" ? "Modifier le cours" : "Edit Course"}</DialogTitle>
            <DialogDescription>
              {language === "ar" ? "تحديث تفاصيل الدرس ورؤيته للتلاميذ." : language === "fr" ? "Mettre à jour les détails du cours et sa visibilité." : "Update the course details and visibility."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-title">{language === "ar" ? "عنوان الدرس *" : language === "fr" ? "Titre du cours *" : "Course Title *"}</Label>
              <Input
                id="edit-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={language === "ar" ? "مثال: الرياضيات المتقدمة" : language === "fr" ? "ex., Mathématiques Appliquées" : "e.g., Introduction to Computer Science"}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">{language === "ar" ? "وصف الدرس" : language === "fr" ? "Description du cours" : "Course Description"}</Label>
              <Textarea
                id="edit-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={language === "ar" ? "قدم وصفاً مفصلاً للمحتوى وأهداف الدرس..." : language === "fr" ? "Fournissez une description détaillée du contenu du cours et des objectifs..." : "Provide a detailed description of the course content, objectives, and what students will learn..."}
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <Label>{language === "ar" ? "مواد الدرس (PDF، صور، فيديوهات)" : language === "fr" ? "Supports de cours (PDF, images, vidéos)" : "Course materials (PDF, images, videos)"}</Label>
              <MultiPdfUpload
                selectedFiles={selectedFiles}
                onFilesChange={setSelectedFiles}
                videoLinks={videoLinks}
                onVideoLinksChange={setVideoLinks}
                existingFiles={existingFiles}
                onRemoveExisting={removeExistingFile}
                maxFiles={20}
                maxSizeMB={50}
              />
            </div>
            <div className="flex items-center gap-2">
              <Switch
                id="edit-visible"
                checked={isVisible}
                onCheckedChange={setIsVisible}
              />
              <Label htmlFor="edit-visible">{language === "ar" ? "جعل الدرس مرئياً للتلاميذ" : language === "fr" ? "Rendre le cours visible pour les élèves" : "Make course visible to students"}</Label>
            </div>
            {!isVisible && <PublishAtField id="edit-publish-at" value={publishAt} onChange={setPublishAt} tr={tr} />}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={resetForm}>
              {language === "ar" ? "إلغاء" : language === "fr" ? "Annuler" : "Cancel"}
            </Button>
            <Button onClick={handleEditCourse} disabled={isSubmitting || !title.trim()}>
              {isSubmitting
                ? (uploadProgress && uploadProgress.total > 0 ? `${language === "ar" ? "رفع" : language === "fr" ? "Téléversement" : "Uploading"} ${Math.min(uploadProgress.done + 1, uploadProgress.total)}/${uploadProgress.total}…` : (language === "ar" ? "جارٍ الحفظ…" : language === "fr" ? "Enregistrement…" : "Saving…"))
                : (language === "ar" ? "تحديث الدرس" : language === "fr" ? "Mettre à jour" : "Update Course")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Course Confirmation Dialog */}
      <Dialog open={!!courseToDelete} onOpenChange={(open) => { if (!open && !deletingCourse) setCourseToDelete(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {language === "ar" ? "حذف الدرس" : language === "fr" ? "Supprimer le cours" : "Delete Course"}
            </DialogTitle>
            <DialogDescription>
              {language === "ar"
                ? `هل أنت متأكد من رغبتك في حذف "${courseToDelete?.title}"؟ لا يمكن التراجع عن هذا الإجراء.`
                : language === "fr"
                ? `Êtes-vous sûr de vouloir supprimer "${courseToDelete?.title}" ? Cette action est irréversible.`
                : `Are you sure you want to delete "${courseToDelete?.title}"? This action cannot be undone.`}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCourseToDelete(null)} disabled={deletingCourse}>
              {language === "ar" ? "إلغاء" : language === "fr" ? "Annuler" : "Cancel"}
            </Button>
            <Button variant="destructive" onClick={confirmDeleteCourse} disabled={deletingCourse}>
              {deletingCourse && <Loader2 className="h-4 w-4 animate-spin" />}
              {deletingCourse ? tr("Suppression…", "جارٍ الحذف…", "Deleting…") : tr("Supprimer le cours", "حذف الدرس", "Delete Course")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <CourseViewerDialog
        open={!!viewerCourse}
        onOpenChange={(o) => { if (!o) setViewerCourse(null); }}
        title={viewerCourse?.title || ""}
        description={viewerCourse?.description}
        subtitle={currentRoom?.name}
        materials={viewerCourse ? (courseMaterials[viewerCourse.id] || []) : []}
      />
      <CopyToDialog source={copySource} onClose={() => setCopySource(null)} onDone={() => refreshData(roomId, { force: true })} tr={tr} />
    </div>
  );
};

export default RoomCourses;