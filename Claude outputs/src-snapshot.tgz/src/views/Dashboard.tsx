import { useEffect, useState, useMemo, useCallback } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useAccess } from "@/contexts/AccessContext";
import { supabase } from "@/integrations/supabase/client";
import { useCourses } from "@/contexts/CourseContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { usePreferences, AttemptPolicy } from "@/contexts/PreferencesContext";
import { useNavigate, Link } from "@/lib/router";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { StatCard } from "@/components/ui/stat-card";
import {
  BookOpen, FileText, Users, Building, Clock, CheckCircle2,
  RefreshCw, ArrowRight, GraduationCap, Target, Trophy, EyeOff, ClipboardList, Play, Timer, AlertTriangle
} from "lucide-react";
import { useNow } from "@/hooks/useNow";
import { WeekSummaryCard } from "@/components/WeekSummaryCard";
import { TodayCard } from "@/components/TodayCard";
import { ParentMessagesCard } from "@/components/ParentMessagesCard";
import { StreakCard } from "@/components/progress/StreakCard";
import { formatDecimal } from "@/lib/formatDate";
import { useAppSettings } from "@/contexts/AppSettingsContext";
import type { Lang } from "@/lib/appSettings";

interface RecentSubmission {
  id: string;
  exam_id: string;
  exam_title: string;
  student_id: string;
  student_name: string;
  student_avatar?: string | null;
  score: number;
  total_points: number;
  pct: number;
  submitted_at: string;
}

interface DayPoint {
  label: string;
  isToday: boolean;
  activeStudents: number;
  submissions: number;
}

const pctOf = (score: number | null, total: number | null) =>
  total && total > 0 ? Math.max(0, Math.min(100, ((score || 0) / total) * 100)) : 0;

/** Couleurs du badge de note selon le pourcentage */
const scoreTone = (pct: number, pass = 50) =>
  pct >= Math.max(70, pass + 10)
    ? { pill: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 ring-emerald-500/30", ring: "#059669" }
    : pct >= pass
    ? { pill: "bg-amber-500/10 text-amber-700 dark:text-amber-300 ring-amber-500/30", ring: "#d97706" }
    : { pill: "bg-rose-500/10 text-rose-700 dark:text-rose-300 ring-rose-500/30", ring: "#e11d48" };

/** Pourcentages retenus par (élève, quiz) selon la règle de tentative choisie dans les paramètres. */
function retainedPcts(
  subs: { student_id: string; exam_id: string; score: number | null; total_points: number | null }[],
  policy: AttemptPolicy
): number[] {
  const groups = new Map<string, number[]>(); // subs triées de la plus récente à la plus ancienne
  subs.filter(s => (s.total_points || 0) > 0).forEach(s => {
    const k = `${s.student_id}|${s.exam_id}`;
    groups.set(k, [...(groups.get(k) || []), pctOf(s.score, s.total_points)]);
  });
  return Array.from(groups.values()).map(list =>
    policy === "best" ? Math.max(...list) : policy === "average" ? list.reduce((a, b) => a + b, 0) / list.length : list[0]
  );
}

const initials = (name: string) => {
  const words = name.trim().split(/\s+/).filter(Boolean);
  // Écriture arabe : une seule lettre (les lettres isolées de deux mots se lisent mal)
  if (/[\u0600-\u06FF]/.test(name)) return (words[0] || "").replace(/^ال/, "").charAt(0) || "؟";
  return words.map(n => n[0]).join("").toUpperCase().slice(0, 2);
};

const Dashboard = () => {
  const { user } = useAuth();
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const {
    courses, exercises, exams, enrollments, rooms, refreshData,
    getVisibleCoursesForStudent, getVisibleExercisesForStudent, getVisibleExamsForStudent,
    quizSubmissions, loading: dataLoading
  } = useCourses();
  const nowTs = useNow();

  const isRtl = language === "ar";
  const { prefs } = usePreferences();
  // Personnalisation centrale : phrase d'accueil et modules activés
  const { settings: appSettings, text: settingText, feature } = useAppSettings();
  const { can } = useAccess();
  const dashboardWelcome = settingText(appSettings.texts?.dashboardWelcome, (language === "ar" || language === "en" ? language : "fr") as Lang);
  const hasCourses = feature("courses");
  const hasExercises = feature("exercises");
  const hasExams = feature("exams");
  const passPct = prefs.passThreshold * 5;
  const passLabel = String(prefs.passThreshold).replace(".", language === "en" ? "." : ",");
  const tr = useCallback((fr: string, ar: string, en: string) => (language === "ar" ? ar : language === "fr" ? fr : en), [language]);
  const locale = language === "ar" ? "ar-MA" : language === "fr" ? "fr-FR" : "en-GB";

  const isProfessor = user?.role === "professor";
  const [selectedRoomId, setSelectedRoomId] = useState<string>("all");
  const [loading, setLoading] = useState<boolean>(false);
  const [totalStudents, setTotalStudents] = useState<number>(0);
  const [recentSubmissions, setRecentSubmissions] = useState<RecentSubmission[]>([]);
  const [avgPct, setAvgPct] = useState<number | null>(null);
  const [passRate, setPassRate] = useState<number | null>(null);
  const [submissionsCount, setSubmissionsCount] = useState<number>(0);
  const [week, setWeek] = useState<DayPoint[]>([]);
  const [metricsError, setMetricsError] = useState(false);
  const [metricsLoaded, setMetricsLoaded] = useState(false);

  /* ───────────── listes filtrées ───────────── */

  const professorRooms = useMemo(() => {
    if (!user) return [];
    if (isProfessor) return rooms.filter(r => r.professor_id === user.id && !r.archived_at);
    const ids = new Set(enrollments.filter(e => e.student_id === user.id).map(e => e.room_id).filter(Boolean));
    return rooms.filter(r => r.is_visible && ids.has(r.id));
  }, [rooms, user, isProfessor, enrollments]);

  const displayCourses = useMemo(() => {
    if (isProfessor) {
      let list = courses.filter(c => c.professor_id === user?.id || professorRooms.some(r => r.id === c.room_id));
      if (selectedRoomId !== "all") list = list.filter(c => c.room_id === selectedRoomId);
      return list;
    }
    return user?.id ? getVisibleCoursesForStudent(user.id) : [];
  }, [courses, user, isProfessor, professorRooms, selectedRoomId, getVisibleCoursesForStudent]);

  const displayCourseIds = useMemo(() => new Set(displayCourses.map(c => c.id)), [displayCourses]);

  const displayExercises = useMemo(() => {
    if (isProfessor) return exercises.filter(ex => displayCourseIds.has(ex.course_id));
    return user?.id ? getVisibleExercisesForStudent(user.id) : [];
  }, [exercises, displayCourseIds, isProfessor, user, getVisibleExercisesForStudent]);

  const displayExams = useMemo(() => {
    if (isProfessor) return exams.filter(ex => displayCourseIds.has(ex.course_id));
    return user?.id ? getVisibleExamsForStudent(user.id) : [];
  }, [exams, displayCourseIds, isProfessor, user, getVisibleExamsForStudent]);

  const examIdsKey = displayExams.map(e => e.id).sort().join(",");

  // Élève : quiz ouverts maintenant et pas encore passés
  const quizzesToDo = useMemo(() => {
    if (isProfessor || !user?.id) return [];
    const now = nowTs;
    const done = new Set((quizSubmissions || []).filter(sub => sub.student_id === user.id).map(sub => sub.exam_id));
    return displayExams
      .filter(ex => ex.type === "quiz" && !done.has(ex.id))
      .filter(ex => {
        const from = new Date((ex as any).available_from || ex.exam_date).getTime();
        const until = (ex as any).available_until ? new Date((ex as any).available_until).getTime() : null;
        return (!from || from <= now) && (!until || until >= now);
      })
      .sort((a, b) => {
        const ua = (a as any).available_until ? new Date((a as any).available_until).getTime() : Infinity;
        const ub = (b as any).available_until ? new Date((b as any).available_until).getTime() : Infinity;
        return ua - ub;
      });
  }, [displayExams, quizSubmissions, isProfessor, user, nowTs]);

  const upcomingExercises = useMemo(() => {
    const now = nowTs, limit = now + 14 * 86400000;
    return displayExercises
      .filter(ex => { const d = new Date(ex.due_date).getTime(); return d >= now && d <= limit; })
      .sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());
  }, [displayExercises, nowTs]);

  // Élève : exercices dont la date limite est dépassée depuis moins de 14 jours
  const overdueExercises = useMemo(() => {
    if (isProfessor) return [];
    const now = nowTs, from = now - 14 * 86400000;
    return displayExercises
      .filter(ex => { const d = new Date(ex.due_date).getTime(); return d < now && d >= from; })
      .sort((a, b) => new Date(b.due_date).getTime() - new Date(a.due_date).getTime());
  }, [displayExercises, nowTs, isProfessor]);

  const upcomingExams = useMemo(() => {
    const now = nowTs, limit = now + 14 * 86400000;
    return displayExams
      .filter(ex => { const d = new Date(ex.exam_date).getTime(); return d >= now && d <= limit; })
      .sort((a, b) => new Date(a.exam_date).getTime() - new Date(b.exam_date).getTime());
  }, [displayExams, nowTs]);

  /* ───────────── indicateurs dynamiques ───────────── */

  const loadDynamicMetrics = useCallback(async () => {
    if (!user?.id) return;
    setLoading(true);
    setMetricsError(false);
    try {
      const examTitle = new Map(displayExams.map(e => [e.id, e.title]));

      if (isProfessor) {
        const roomIds = selectedRoomId === "all" ? professorRooms.map(r => r.id) : [selectedRoomId];

        // 1. Élèves (profil rattaché à la classe OU inscription)
        const studentSet = new Set<string>();
        if (roomIds.length > 0) {
          const [{ data: s1 }, { data: s2 }] = await Promise.all([
            supabase.from("profiles").select("id").eq("role", "student").in("room_id", roomIds),
            supabase.from("enrollments").select("student_id").in("room_id", roomIds),
          ]);
          s1?.forEach(s => studentSet.add(s.id));
          s2?.forEach(e => studentSet.add(e.student_id));
        }
        setTotalStudents(studentSet.size);

        // 2. Toutes les copies de quiz (pas seulement les 20 dernières)
        const examIds = displayExams.map(e => e.id);
        let subs: { id: string; exam_id: string; student_id: string; score: number | null; total_points: number | null; submitted_at: string }[] = [];
        if (examIds.length > 0) {
          const { data, error } = await supabase
            .from("quiz_submissions")
            .select("id, exam_id, student_id, score, total_points, submitted_at")
            .in("exam_id", examIds)
            .eq("is_completed", true)
            .order("submitted_at", { ascending: false });
          if (error) throw error;
          subs = data || [];
        }
        setSubmissionsCount(subs.length);

        // Moyenne = moyenne des POURCENTAGES (score / total), une note retenue par élève et par quiz
        const pcts = retainedPcts(subs, prefs.attemptPolicy);
        setAvgPct(pcts.length ? pcts.reduce((a, b) => a + b, 0) / pcts.length : null);
        setPassRate(pcts.length ? (pcts.filter(p => p >= passPct).length / pcts.length) * 100 : null);

        // 3. Dernières copies avec noms
        const recent = subs.slice(0, 6);
        const ids = Array.from(new Set(recent.map(s => s.student_id)));
        const { data: profiles } = ids.length
          ? await supabase.from("profiles").select("id, name, avatar_url").in("id", ids)
          : { data: [] as any[] };
        const pmap = new Map((profiles || []).map((p: any) => [p.id, p]));
        setRecentSubmissions(recent.map(s => {
          const p: any = pmap.get(s.student_id);
          return {
            id: s.id,
            exam_id: s.exam_id,
            exam_title: examTitle.get(s.exam_id) || tr("Quiz", "اختبار", "Quiz"),
            student_id: s.student_id,
            student_name: p?.name || tr("Élève", "تلميذ", "Student"),
            student_avatar: p?.avatar_url,
            score: s.score || 0,
            total_points: s.total_points || 0,
            pct: pctOf(s.score, s.total_points),
            submitted_at: s.submitted_at,
          };
        }));

        // 4. Activité des 7 derniers jours (2 requêtes au lieu de 14)
        const start = new Date();
        start.setHours(0, 0, 0, 0);
        start.setDate(start.getDate() - 6);
        const days: DayPoint[] = [];
        const dayKey = (d: Date) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
        const index = new Map<string, { students: Set<string>; subs: number }>();
        for (let i = 0; i < 7; i++) {
          const d = new Date(start);
          d.setDate(start.getDate() + i);
          index.set(dayKey(d), { students: new Set(), subs: 0 });
          days.push({ label: d.toLocaleDateString(locale, { weekday: "short" }), isToday: i === 6, activeStudents: 0, submissions: 0 });
        }
        if (studentSet.size > 0) {
          const { data: acts } = await supabase
            .from("student_activities")
            .select("student_id, created_at")
            .in("student_id", Array.from(studentSet))
            .gte("created_at", start.toISOString());
          acts?.forEach(a => index.get(dayKey(new Date(a.created_at)))?.students.add(a.student_id));
        }
        subs.forEach(s => {
          const d = new Date(s.submitted_at);
          if (d >= start) {
            const slot = index.get(dayKey(d));
            if (slot) slot.subs++;
          }
        });
        Array.from(index.values()).forEach((v, i) => {
          days[i].activeStudents = v.students.size;
          days[i].submissions = v.subs;
        });
        setWeek(days);
      } else {
        // Élève : ses propres résultats
        const { data, error } = await supabase
          .from("quiz_submissions")
          .select("id, exam_id, student_id, score, total_points, submitted_at")
          .eq("student_id", user.id)
          .eq("is_completed", true)
          .order("submitted_at", { ascending: false });
        if (error) throw error;
        const subs = data || [];
        setSubmissionsCount(subs.length);
        const latest = new Map<string, (typeof subs)[number]>();
        subs.forEach(s => { if (!latest.has(s.exam_id)) latest.set(s.exam_id, s); });
        const pcts = retainedPcts(subs, prefs.attemptPolicy);
        setAvgPct(pcts.length ? pcts.reduce((a, b) => a + b, 0) / pcts.length : null);
        setPassRate(pcts.length ? (pcts.filter(p => p >= passPct).length / pcts.length) * 100 : null);
        setRecentSubmissions(Array.from(latest.values()).slice(0, 6).map(s => ({
          id: s.id,
          exam_id: s.exam_id,
          exam_title: examTitle.get(s.exam_id) || exams.find(e => e.id === s.exam_id)?.title || tr("Quiz", "اختبار", "Quiz"),
          student_id: s.student_id,
          student_name: user.name || "",
          score: s.score || 0,
          total_points: s.total_points || 0,
          pct: pctOf(s.score, s.total_points),
          submitted_at: s.submitted_at,
        })));
      }
      setMetricsLoaded(true);
    } catch (err) {
      console.error("Failed to load dashboard dynamic metrics:", err);
      setMetricsError(true);
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, isProfessor, selectedRoomId, examIdsKey, professorRooms.length, locale, prefs.attemptPolicy, passPct]);

  useEffect(() => {
    loadDynamicMetrics();
  }, [loadDynamicMetrics]);

  const handleRefresh = () => {
    refreshData(undefined, { force: true });
    loadDynamicMetrics();
  };

  /* ───────────── helpers d'affichage ───────────── */

  const fmtNote20 = (pct: number | null) => {
    if (pct === null) return "—";
    return formatDecimal(pct / 5, language);
  };

  const relative = (iso: string) => {
    const rtf = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
    const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (m < 60) return rtf.format(-Math.max(0, m), "minute");
    const h = Math.round(m / 60);
    if (h < 24) return rtf.format(-h, "hour");
    return rtf.format(-Math.round(h / 24), "day");
  };

  const until = (iso: string) => {
    const rtf = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
    const ms = new Date(iso).getTime() - nowTs;
    const h = Math.round(ms / 3600000);
    if (h < 24) return rtf.format(Math.max(0, h), "hour");
    return rtf.format(Math.round(h / 24), "day");
  };

  const today = new Date().toLocaleDateString(locale, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const trackingLink = selectedRoomId !== "all"
    ? `/rooms/${selectedRoomId}/students-activities`
    : professorRooms[0] ? `/rooms/${professorRooms[0].id}/students-activities` : "/reports";

  const DateTile = ({ iso, tone }: { iso: string; tone: "indigo" | "emerald" }) => {
    const d = new Date(iso);
    return (
      <div className="flex h-11 w-11 shrink-0 flex-col items-center justify-center overflow-hidden rounded-md border bg-card text-foreground" data-tone={tone}>
        <span className="text-2xs font-medium uppercase leading-tight text-muted-foreground">{d.toLocaleDateString(locale, { month: "short" })}</span>
        <span className="text-base font-semibold leading-none tabular-nums">{d.getDate()}</span>
      </div>
    );
  };

  const maxWeek = Math.max(1, ...week.map(d => Math.max(d.activeStudents, d.submissions)));
  const weekSummary = week
    .map(d => `${d.label} : ${d.activeStudents} ${tr("actifs", "نشطون", "active")}, ${d.submissions} ${tr("copies", "أوراق", "submissions")}`)
    .join(" ; ");
  const firstLoad = (loading && !metricsLoaded) || (dataLoading && courses.length === 0);
  const Pulse = ({ className }: { className: string }) => <div className={`rounded-xl bg-muted motion-safe:animate-pulse ${className}`} />;

  /* ═══════════════════════════════ RENDU ═══════════════════════════════ */

  return (
    <div className="space-y-6 pb-8" dir={isRtl ? "rtl" : "ltr"}>
      {/* ── En-tête simple ── */}
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-medium text-muted-foreground first-letter:uppercase">{today}</p>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight">
            {t("dashboard.welcome")}, {user?.name}
          </h1>
          {dashboardWelcome && (
            <p className="mt-1.5 max-w-2xl whitespace-pre-line text-sm font-medium text-foreground/80">{dashboardWelcome}</p>
          )}
          <p className="mt-1 max-w-xl text-sm text-muted-foreground">
            {isProfessor
              ? tr("Voici l'essentiel de vos classes : résultats, activité et échéances.", "إليك أهم مستجدات أقسامك: النتائج والنشاط والمواعيد.", "Here is the essentials of your classes: results, activity and deadlines.")
              : tr("Suivez vos cours, vos résultats et vos prochaines échéances.", "تابع دروسك ونتائجك ومواعيدك القادمة.", "Track your courses, results and upcoming deadlines.")}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {isProfessor && professorRooms.length > 0 && (
            <Select value={selectedRoomId} onValueChange={setSelectedRoomId}>
              <SelectTrigger className="w-[200px]">
                <Building className="h-4 w-4 me-2 text-muted-foreground" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{tr("Toutes les classes", "كل الأقسام", "All classes")}</SelectItem>
                {professorRooms.map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
              </SelectContent>
            </Select>
          )}
          <Button variant="outline" onClick={handleRefresh} disabled={loading} className="gap-2">
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            <span className="hidden sm:inline">{tr("Actualiser", "تحديث", "Refresh")}</span>
          </Button>
        </div>
      </div>

      {metricsError && (
        <div role="alert" className="flex flex-col gap-3 rounded-xl border border-rose-300 bg-rose-50 p-4 text-sm text-rose-800 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-200 sm:flex-row sm:items-center sm:justify-between">
          <span className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            {tr("Impossible de charger les résultats. Vérifie ta connexion.", "تعذر تحميل النتائج. تحقق من الاتصال.", "Unable to load results. Check your connection.")}
          </span>
          <Button variant="outline" onClick={handleRefresh} disabled={loading} className="h-10 gap-2 bg-background">
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            {tr("Réessayer", "إعادة المحاولة", "Try again")}
          </Button>
        </div>
      )}

      {isProfessor && professorRooms.length > 0 && can("dashboard.today") && <TodayCard />}
      {isProfessor && feature("parents") && can("parents.messages") && <ParentMessagesCard />}
      {isProfessor && professorRooms.length > 0 && <WeekSummaryCard />}
      {user?.role === "student" && <StreakCard />}

      {/* ── Aucune classe ── */}
      {isProfessor && professorRooms.length === 0 && !firstLoad && (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center py-12 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-primary/10 text-primary"><Building className="h-8 w-8" /></div>
            <CardTitle className="text-base">{t("dashboard.welcome.platform")}</CardTitle>
            <CardDescription className="mt-2 max-w-md text-base">
              {tr("Commencez par créer une classe pour organiser vos élèves, cours et évaluations.", "ابدأ بإنشاء قسم لتنظيم التلاميذ والدروس والتقويمات.", "Start by creating a class to organise students, courses and assessments.")}
            </CardDescription>
            <Button onClick={() => navigate("/class-management")} size="lg" className="mt-5 gap-2">
              <Building className="h-4 w-4" />
              {tr("Créer ma première classe", "إنشاء قسمي الأول", "Create my first class")}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ── Élève : à faire maintenant ── */}
      {!isProfessor && hasExams && quizzesToDo.length > 0 && (
        <Card className="overflow-hidden border-emerald-300 dark:border-emerald-800">
          <CardHeader className="bg-emerald-500/10 pb-3">
            <CardTitle className="flex items-center gap-2 text-base text-emerald-800 dark:text-emerald-300">
              <Play className="h-5 w-5" />
              {tr("À faire maintenant", "مطلوب الآن", "To do now")}
              <span className="rounded-full bg-emerald-600 px-2 py-0.5 text-xs font-semibold text-white">{quizzesToDo.length}</span>
            </CardTitle>
            <CardDescription>{tr("Ces quiz sont ouverts : passez-les avant la fermeture.", "هذه الاختبارات مفتوحة الآن: اجتزها قبل إغلاقها.", "These quizzes are open: take them before they close.")}</CardDescription>
          </CardHeader>
          <CardContent className="divide-y p-0">
            {quizzesToDo.slice(0, 5).map(ex => {
              const until = (ex as any).available_until ? new Date((ex as any).available_until) : null;
              return (
                <div key={ex.id} className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{ex.title}</p>
                    <p className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                      <span>{courses.find(c => c.id === ex.course_id)?.title}</span>
                      {ex.duration_minutes ? (
                        <span className="inline-flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{ex.duration_minutes} {tr("min", "دقيقة", "min")}</span>
                      ) : null}
                      {until && (
                        <span className="inline-flex items-center gap-1 text-rose-600 dark:text-rose-400">
                          <Timer className="h-3.5 w-3.5" />
                          {tr("jusqu'au", "إلى غاية", "until")} {until.toLocaleString(locale, { day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" })}
                        </span>
                      )}
                    </p>
                  </div>
                  <Button asChild className="h-10 shrink-0 gap-2 bg-emerald-600 font-semibold text-white hover:bg-emerald-700">
                    <Link to={`/exams?quiz=${ex.id}`}>
                      <Play className="h-4 w-4" />
                      {tr("Commencer", "ابدأ", "Start")}
                    </Link>
                  </Button>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* ── Indicateurs ── */}
      <div className={`grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 ${isProfessor ? "xl:grid-cols-6" : "xl:grid-cols-5"}`}>
        {isProfessor && (
          <StatCard tone="indigo" icon={<Building className="h-5 w-5" />} label={tr("Classes", "الأقسام", "Classes")} value={selectedRoomId === "all" ? professorRooms.length : 1} hint={tr("classes actives", "أقسام نشطة", "active classes")} onClick={() => navigate("/class-management")} />
        )}
        {isProfessor && (
          <StatCard tone="amber" icon={<Users className="h-5 w-5" />} label={tr("Élèves", "التلاميذ", "Students")} value={totalStudents} hint={tr("élèves inscrits", "تلميذ مسجل", "enrolled students")} />
        )}
        {hasCourses && <StatCard tone="blue" icon={<BookOpen className="h-5 w-5" />} label={tr("Cours", "الدروس", "Courses")} value={displayCourses.length} hint={isProfessor ? tr("cours publiés", "دروس منشورة", "published courses") : tr("cours suivis", "دروس متابعة", "courses followed")} onClick={() => navigate("/courses")} />}
        {hasExercises && <StatCard tone="violet" icon={<FileText className="h-5 w-5" />} label={tr("Exercices", "التمارين", "Exercises")} value={displayExercises.length} hint={tr(`${upcomingExercises.length} à rendre sous 14 j`, `${upcomingExercises.length} للتسليم خلال 14 يوماً`, `${upcomingExercises.length} due within 14 days`)} onClick={() => navigate("/exercises")} />}
        {hasExams && <StatCard tone="cyan" icon={<ClipboardList className="h-5 w-5" />} label={tr("Évaluations", "التقويمات", "Assessments")} value={displayExams.length} hint={tr(`${submissionsCount} copie(s) rendue(s)`, `${submissionsCount} ورقة مسلَّمة`, `${submissionsCount} submission(s)`)} onClick={() => navigate("/exams")} />}
        {hasExams && <StatCard
          tone="emerald"
          icon={<GraduationCap className="h-5 w-5" />}
          label={isProfessor ? tr("Moyenne aux quiz", "معدل الاختبارات", "Quiz average") : tr("Ma moyenne", "معدلي", "My average")}
          value={<span dir="ltr" className="inline-block">{fmtNote20(avgPct)}<span className="text-base font-semibold text-muted-foreground"> /20</span></span>}
          hint={passRate === null ? tr("aucune copie pour l'instant", "لا توجد أوراق بعد", "no submissions yet") : tr(`${Math.round(passRate)} % de notes ≥ ${passLabel}/20`, `${Math.round(passRate)}% من النقط ≥ ${passLabel}/20`, `${Math.round(passRate)}% of grades ≥ ${passLabel}/20`)}
          progress={avgPct}
        />}
      </div>

      {/* ── Activité & dernières copies ── */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-5">
        {isProfessor && (
          <Card className={hasExams ? "lg:col-span-3" : "lg:col-span-5"}>
            <CardHeader className="flex-row items-start justify-between space-y-0 pb-2">
              <div>
                <CardTitle className="text-base">{tr("Activité des 7 derniers jours", "نشاط آخر 7 أيام", "Last 7 days activity")}</CardTitle>
                <CardDescription className="mt-1.5">{tr("Élèves actifs et copies de quiz rendues chaque jour", "التلاميذ النشطون والأوراق المسلمة يومياً", "Active students and quiz submissions per day")}</CardDescription>
              </div>
              {feature("reports") && <Button asChild variant="ghost" size="sm" className="gap-1 text-xs"><Link to="/reports">{tr("Rapports", "التقارير", "Reports")}<ArrowRight className={`h-3.5 w-3.5 ${isRtl ? "rotate-180" : ""}`} /></Link></Button>}
            </CardHeader>
            <CardContent>
              {firstLoad && week.length === 0 ? (
                <Pulse className="h-[200px] w-full" />
              ) : (
              <div className="flex h-[200px] items-end gap-2 sm:gap-4 border-b pb-1 pt-5" role="img" aria-label={`${tr("Activité des 7 derniers jours", "نشاط آخر 7 أيام", "Last 7 days activity")} — ${weekSummary}`}>
                {week.map((d, i) => (
                  <div key={i} className="group flex h-full flex-1 flex-col justify-end" aria-hidden="true">
                    <div className="relative flex flex-1 items-end justify-center gap-1">
                      {/* Valeurs toujours visibles (pas seulement au survol : tablettes / téléphones) */}
                      <div className="flex h-full w-1/2 max-w-[22px] flex-col items-center justify-end">
                        <span className="mb-0.5 text-[11px] font-medium tabular-nums leading-none text-foreground">{d.activeStudents}</span>
                        <div className="w-full rounded-t-[3px] bg-primary motion-safe:transition-all motion-safe:duration-700" style={{ height: `${(d.activeStudents / maxWeek) * 85}%`, minHeight: d.activeStudents ? 4 : 0 }} />
                      </div>
                      <div className="flex h-full w-1/2 max-w-[22px] flex-col items-center justify-end">
                        <span className="mb-0.5 text-[11px] font-medium tabular-nums leading-none text-muted-foreground">{d.submissions}</span>
                        <div className="w-full rounded-t-[3px] bg-foreground/20 motion-safe:transition-all motion-safe:duration-700" style={{ height: `${(d.submissions / maxWeek) * 85}%`, minHeight: d.submissions ? 4 : 0 }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              )}
              <div className="mt-2 flex gap-2 sm:gap-4">
                {week.map((d, i) => (
                  <span key={i} className={`flex-1 text-center text-[11px] capitalize ${d.isToday ? "font-medium text-foreground" : "text-muted-foreground"}`}>{d.label}</span>
                ))}
              </div>
              <div className="mt-3 flex flex-wrap gap-4 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-primary" />{tr("Élèves actifs", "تلاميذ نشطون", "Active students")}</span>
                <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-foreground/25" />{tr("Copies de quiz", "أوراق الاختبارات", "Quiz submissions")}</span>
              </div>
            </CardContent>
          </Card>
        )}

        {hasExams && (
        <Card className={isProfessor ? "lg:col-span-2" : "lg:col-span-5"}>
          <CardHeader className="flex-row items-start justify-between space-y-0 pb-3">
            <div>
              <CardTitle className="text-base">{isProfessor ? tr("Dernières copies de quiz", "آخر أوراق الاختبارات", "Latest quiz submissions") : tr("Mes derniers résultats", "آخر نتائجي", "My latest results")}</CardTitle>
              <CardDescription className="mt-1.5">{tr("Note obtenue sur le total de points du quiz", "النقطة المحصل عليها من مجموع نقط الاختبار", "Score out of the quiz total points")}</CardDescription>
            </div>
            {isProfessor && professorRooms.length > 0 && feature("studentActivities") && (
              <Button asChild variant="ghost" size="sm" className="gap-1 text-xs"><Link to={trackingLink}>{tr("Suivi", "التتبع", "Tracking")}<ArrowRight className={`h-3.5 w-3.5 ${isRtl ? "rotate-180" : ""}`} /></Link></Button>
            )}
          </CardHeader>
          <CardContent className={isProfessor ? "space-y-2" : "grid gap-2 sm:grid-cols-2 lg:grid-cols-3"}>
            {firstLoad && recentSubmissions.length === 0 ? (
              [0, 1, 2].map(i => <Pulse key={i} className="h-16 w-full" />)
            ) : recentSubmissions.length > 0 ? recentSubmissions.map(sub => {
              const tone = scoreTone(sub.pct, passPct);
              return (
                <Link
                  key={sub.id}
                  to={isProfessor ? `/exams` : `/exams?quiz=${sub.exam_id}`}
                  className="group flex items-center gap-3 rounded-lg border p-3 transition-colors hover:bg-muted/50 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  {isProfessor ? (
                    <Avatar className="h-10 w-10 shrink-0">
                      <AvatarImage src={sub.student_avatar || undefined} />
                      <AvatarFallback className="bg-muted text-xs font-medium text-foreground">{initials(sub.student_name)}</AvatarFallback>
                    </Avatar>
                  ) : (
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md border bg-background text-muted-foreground"><Trophy className="h-4 w-4" /></div>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{isProfessor ? sub.student_name : sub.exam_title}</p>
                    <p className="truncate text-[11px] text-muted-foreground">{isProfessor ? `${sub.exam_title} · ` : ""}{relative(sub.submitted_at)}</p>
                  </div>
                  <div className="shrink-0 text-end">
                    <span dir="ltr" className={`inline-flex items-baseline gap-0.5 rounded-xl px-2.5 py-1 text-sm font-semibold tabular-nums ring-1 ${tone.pill}`}>
                      {formatDecimal(sub.score, language, 2)}<span className="text-[11px] font-semibold opacity-70">/{sub.total_points}</span>
                    </span>
                    <p dir="ltr" className="mt-1 text-[11px] font-medium text-muted-foreground tabular-nums">{Math.round(sub.pct)} % · {fmtNote20(sub.pct)}/20</p>
                  </div>
                </Link>
              );
            }) : (
              <div className="col-span-full flex flex-col items-center justify-center py-10 text-center text-muted-foreground">
                <CheckCircle2 className="mb-3 h-5 w-5 opacity-60" />
                <p className="text-sm">{tr("Aucune copie pour l'instant", "لا توجد أوراق بعد", "No submissions yet")}</p>
              </div>
            )}
          </CardContent>
        </Card>
        )}
      </div>

      {/* ── Élève : exercices en retard (14 derniers jours) ── */}
      {!isProfessor && hasExercises && overdueExercises.length > 0 && (
        <Card className="border-rose-300 dark:border-rose-900">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base text-rose-700 dark:text-rose-300">
              <AlertTriangle className="h-5 w-5" />
              {tr("En retard", "متأخر", "Overdue")}
              <span className="rounded-full bg-rose-600 px-2 py-0.5 text-xs font-semibold text-white">{overdueExercises.length}</span>
            </CardTitle>
            <CardDescription>{tr("Exercices dont la date limite est passée (14 derniers jours).", "تمارين تجاوزت موعد التسليم (آخر 14 يوماً).", "Exercises past their due date (last 14 days).")}</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {overdueExercises.slice(0, 5).map(ex => (
                <li key={ex.id}>
                  <Link to={`/exercises?course=${ex.course_id}`} className="flex items-center gap-3 rounded-lg border p-2.5 transition-colors hover:bg-muted/50 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{ex.title}</p>
                      <p className="truncate text-[11px] text-muted-foreground">{courses.find(c => c.id === ex.course_id)?.title}</p>
                    </div>
                    <span className="shrink-0 rounded-full bg-rose-500/10 px-2.5 py-1 text-[11px] font-semibold text-rose-700 dark:text-rose-300">
                      {new Date(ex.due_date).toLocaleDateString(locale, { day: "numeric", month: "short" })}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* ── Échéances ── */}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        {[
          {
            key: "ex",
            title: t("dashboard.deadlines"),
            desc: t("dashboard.deadlines.desc"),
            icon: null,
            items: upcomingExercises.slice(0, 5).map(ex => ({ id: ex.id, title: ex.title, course: courses.find(c => c.id === ex.course_id)?.title, date: ex.due_date, badge: null as string | null, to: `/exercises?course=${ex.course_id}` })),
            empty: t("dashboard.no.deadlines"),
            tone: "indigo" as const,
          },
          {
            key: "exam",
            title: t("dashboard.upcoming.exams"),
            desc: t("dashboard.upcoming.exams.desc"),
            icon: null,
            items: upcomingExams.slice(0, 5).map(ex => ({ id: ex.id, title: ex.title, course: courses.find(c => c.id === ex.course_id)?.title, date: ex.exam_date, badge: ex.type === "quiz" ? tr("Quiz", "اختبار", "Quiz") : tr("Examen", "امتحان", "Exam"), to: ex.type === "quiz" && !isProfessor ? `/exams?quiz=${ex.id}` : `/exams?course=${ex.course_id}` })),
            empty: t("dashboard.no.exams"),
            tone: "emerald" as const,
          },
        ].filter(block => (block.key === "ex" ? hasExercises : hasExams)).map(block => (
          <Card key={block.key}>
            <CardHeader className="flex-row items-start justify-between space-y-0 pb-3">
              <div>
                <CardTitle className="text-base">{block.title}</CardTitle>
                <CardDescription className="mt-1.5">{block.desc}</CardDescription>
              </div>
              
            </CardHeader>
            <CardContent>
              {block.items.length > 0 ? (
                <ul className="space-y-2">
                  {block.items.map(it => (
                    <li key={it.id}>
                    <Link to={it.to} className="flex items-center gap-3 rounded-lg border p-2.5 transition-colors hover:bg-muted/50 focus:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                      <DateTile iso={it.date} tone={block.tone} />
                      <div className="min-w-0 flex-1">
                        <p className="flex items-center gap-1.5 truncate text-sm font-semibold">
                          <span className="truncate">{it.title}</span>
                          {it.badge && <span className="shrink-0 rounded-md bg-muted px-1.5 py-0.5 text-[11px] font-semibold text-muted-foreground">{it.badge}</span>}
                        </p>
                        <p className="truncate text-[11px] text-muted-foreground">{it.course}</p>
                      </div>
                      <span className="shrink-0 rounded-md border px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
                        {until(it.date)}
                      </span>
                    </Link>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="flex flex-col items-center py-8 text-center text-sm text-muted-foreground">
                  <CheckCircle2 className="mb-2 h-5 w-5 text-muted-foreground/60" />
                  {block.empty}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* ── Cours ── */}
      {hasCourses && (
      <Card>
        <CardHeader className="flex-row items-start justify-between space-y-0 pb-3">
          <div>
            <CardTitle className="text-base">{t("dashboard.your.courses")}</CardTitle>
            <CardDescription className="mt-1.5">
              {isProfessor ? tr("Vos cours actifs, leurs élèves et leurs évaluations", "دروسك النشطة وتلاميذها وتقويماتها", "Your active courses, students and assessments") : t("dashboard.your.courses.student")}
            </CardDescription>
          </div>
          {isProfessor && (
            <Button asChild variant="outline" size="sm" className="gap-1 text-xs"><Link to="/courses">{tr("Gérer les cours", "إدارة الدروس", "Manage courses")}<ArrowRight className={`h-3.5 w-3.5 ${isRtl ? "rotate-180" : ""}`} /></Link></Button>
          )}
        </CardHeader>
        <CardContent>
          {dataLoading && displayCourses.length === 0 ? (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3" aria-busy="true">
              {[0, 1, 2].map(i => <Pulse key={i} className="h-28 w-full" />)}
            </div>
          ) : displayCourses.length > 0 ? (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
              {displayCourses.map((course) => {
                const nStudents = enrollments.filter(e => e.course_id === course.id).length;
                const nEx = (isProfessor ? exercises : displayExercises).filter(e => e.course_id === course.id).length;
                const nExams = (isProfessor ? exams : displayExams).filter(e => e.course_id === course.id).length;
                return (
                  <Link
                    key={course.id}
                    to={isProfessor && course.room_id ? `/rooms/${course.room_id}/courses` : "/courses"}
                    className="block rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                  <Card className="card-hover h-full overflow-hidden">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md border bg-background text-muted-foreground">
                          <BookOpen className="h-4 w-4" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <p className="truncate font-semibold" title={course.title}>{course.title}</p>
                            {!course.is_visible && (
                              <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-amber-500/10 px-2 py-0.5 text-[11px] font-semibold text-amber-700 dark:text-amber-300">
                                <EyeOff className="h-3 w-3" />{t("dashboard.hidden")}
                              </span>
                            )}
                          </div>
                          <p className="mt-0.5 line-clamp-2 min-h-[32px] text-xs text-muted-foreground">
                            {course.description || tr("Aucune description", "لا يوجد وصف", "No description")}
                          </p>
                        </div>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-1.5 border-t pt-3 text-[11px] font-medium">
                        {isProfessor && <span className="inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-muted-foreground"><Users className="h-3 w-3" />{nStudents} {tr("élèves", "تلميذ", "students")}</span>}
                        {hasExercises && <span className="inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-muted-foreground"><FileText className="h-3 w-3" />{nEx} {tr("exercices", "تمارين", "exercises")}</span>}
                        {hasExams && <span className="inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-muted-foreground"><Target className="h-3 w-3" />{nExams} {tr("évaluations", "تقويمات", "assessments")}</span>}
                      </div>
                    </CardContent>
                  </Card>
                  </Link>
                );
              })}
            </div>
          ) : (
            <div className="flex flex-col items-center py-10 text-center text-sm text-muted-foreground">
              <BookOpen className="mb-3 h-5 w-5 opacity-60" />
              {user?.role === "student" ? t("dashboard.no.courses.student") : t("dashboard.no.courses.professor")}
            </div>
          )}
        </CardContent>
      </Card>
      )}
    </div>
  );
};

export default Dashboard;
