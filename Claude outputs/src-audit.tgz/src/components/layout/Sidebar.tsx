import { useState } from "react";
import { NavLink, useParams, useNavigate } from "@/lib/router";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useCourses } from "@/contexts/CourseContext";
import { useAccess } from "@/contexts/AccessContext";
import { useStudentFeatures } from "@/lib/studentFeatures";
import { useLab3dFeatures } from "@/lib/lab3d/features";
import { useChatOptional } from "@/contexts/ChatContext";
import { ChatUnreadBadge } from "@/components/chat/ChatNavButton";
import { contactInRoom } from "@/lib/chat";
import { useAppSettings } from "@/contexts/AppSettingsContext";
import { useClassModule } from "@/lib/classModules";
import {
  Boxes,
  LayoutGrid,
  BookOpen,
  FileText,
  Users,
  ClipboardCheck,
  Settings,
  UserRound,
  ChevronRight,
  FolderKanban,
  BarChart3,
  Activity,
  FileSpreadsheet,
  FilePen,
  LogOut,
  CreditCard,
  Lock,
  Plus,
  CalendarDays,
  CalendarCheck,
  Layers,
  Library,
  LibraryBig,
  LifeBuoy,
  MessageCircle,
  TrendingUp,
  BookOpenCheck,
  Table2,
  Sparkles,
  type LucideIcon,
  Video,
  PenLine,
  Briefcase,
  FileType2,
  Sheet,
  Presentation,
  DraftingCompass,
  ShieldCheck,
  Timer,
  GraduationCap,
  House,
  FolderOpen,
  CalendarClock,
} from "lucide-react";
import { GGB_APPS } from "@/components/geogebra/ggbApps";
import { usePathname } from "next/navigation";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LanguageSelector } from "@/components/LanguageSelector";
import { ThemeToggle } from "@/components/ThemeToggle";
import { BrandMark, useBrand } from "@/components/AppBrand";
import { cn } from "@/lib/utils";

export const initialsOf = (name?: string | null) =>
  (name || "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0])
    .join("")
    .toUpperCase() || "U";

const itemClass = (isActive: boolean, nested = false) =>
  cn(
    "group flex w-full items-center gap-2.5 rounded-md text-[13px] font-medium transition-colors",
    nested ? "h-8 px-2" : "h-9 px-2.5",
    isActive
      ? "bg-sidebar-accent text-sidebar-accent-foreground"
      : "text-sidebar-foreground hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground"
  );

/** « Outils Office » : sous-menu Word / Excel / PowerPoint (ouvert automatiquement sur ces pages) */
function OfficeMenu({ t, isRtl }: { t: (fr: string, ar: string, en: string) => string; isRtl: boolean }) {
  const pathname = usePathname() || "";
  const inOffice = pathname.startsWith("/office");
  const [open, setOpen] = useState<boolean | null>(null);
  const isOpen = open ?? inOffice;
  return (
    <Collapsible open={isOpen} onOpenChange={(v) => setOpen(v)}>
      <CollapsibleTrigger
        className={cn(
          "group flex h-9 w-full items-center gap-2.5 rounded-md px-2.5 text-[13px] font-medium transition-colors",
          inOffice ? "text-foreground" : "text-sidebar-foreground",
          "hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground"
        )}
      >
        <Briefcase className={cn("h-4 w-4 shrink-0", inOffice ? "text-sidebar-primary" : "text-muted-foreground")} strokeWidth={1.75} />
        <span className="min-w-0 flex-1 truncate text-start">{t("Outils Office", "أدوات أوفيس", "Office tools")}</span>
        <ChevronRight
          className={cn(
            "h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform duration-150",
            isRtl && "rotate-180",
            isOpen && (isRtl ? "-rotate-90" : "rotate-90")
          )}
        />
      </CollapsibleTrigger>
      <CollapsibleContent className="ms-[17px] space-y-0.5 border-s ps-2 pt-0.5">
        <NavItem nested to="/office/word" icon={FileType2} label={t("Word · Traitement de texte", "Word · معالجة النصوص", "Word · Documents")} />
        <NavItem nested to="/office/excel" icon={Sheet} label={t("Excel · Tableur", "Excel · جداول البيانات", "Excel · Spreadsheets")} />
        <NavItem nested to="/office/powerpoint" icon={Presentation} label={t("PowerPoint · Présentation", "PowerPoint · العروض", "PowerPoint · Slides")} />
      </CollapsibleContent>
    </Collapsible>
  );
}

/** « GeoGebra » : sous-menu des applications GeoGebra (ouvert automatiquement sur ces pages) */
function GeoGebraMenu({ t, isRtl }: { t: (fr: string, ar: string, en: string) => string; isRtl: boolean }) {
  const pathname = usePathname() || "";
  const inGgb = pathname.startsWith("/geogebra");
  const [open, setOpen] = useState<boolean | null>(null);
  const isOpen = open ?? inGgb;
  const L = (fr: string, ar: string, en?: string) => t(fr, ar, en ?? fr);
  return (
    <Collapsible open={isOpen} onOpenChange={(v) => setOpen(v)}>
      <CollapsibleTrigger
        className={cn(
          "group flex h-9 w-full items-center gap-2.5 rounded-md px-2.5 text-[13px] font-medium transition-colors",
          inGgb ? "text-foreground" : "text-sidebar-foreground",
          "hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground"
        )}
      >
        <DraftingCompass className={cn("h-4 w-4 shrink-0", inGgb ? "text-sidebar-primary" : "text-muted-foreground")} strokeWidth={1.75} />
        <span className="min-w-0 flex-1 truncate text-start">GeoGebra</span>
        <ChevronRight
          className={cn(
            "h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform duration-150",
            isRtl && "rotate-180",
            isOpen && (isRtl ? "-rotate-90" : "rotate-90")
          )}
        />
      </CollapsibleTrigger>
      <CollapsibleContent className="ms-[17px] space-y-0.5 border-s ps-2 pt-0.5">
        <NavItem nested end to="/geogebra" icon={DraftingCompass} label={t("Toutes les applications", "كل التطبيقات", "All apps")} />
        {GGB_APPS.map((a) => (
          <NavItem key={a.id} nested to={`/geogebra/${a.id}`} icon={a.icon} label={a.label(L)} />
        ))}
      </CollapsibleContent>
    </Collapsible>
  );
}

/**
 * Sous-menu repliable (« Exams programmés », « Exams ») : ouvert automatiquement
 * quand la page courante est l'une de ses entrées.
 */
type SubItem = { to: string; icon: LucideIcon; label: string; locked?: boolean };
function SubMenu({ icon: Icon, label, items, nested, isRtl }: { icon: LucideIcon; label: string; items: SubItem[]; nested?: boolean; isRtl: boolean }) {
  const pathname = usePathname() || "";
  const inside = items.some((i) => pathname === i.to || pathname.startsWith(i.to + "/"));
  const [open, setOpen] = useState<boolean | null>(null);
  const isOpen = open ?? inside;
  if (items.length === 0) return null;
  return (
    <Collapsible open={isOpen} onOpenChange={(v) => setOpen(v)}>
      <CollapsibleTrigger
        className={cn(
          "group flex w-full items-center gap-2.5 rounded-md text-[13px] font-medium transition-colors",
          nested ? "h-8 px-2" : "h-9 px-2.5",
          inside ? "text-foreground" : "text-sidebar-foreground",
          "hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground"
        )}
      >
        <Icon className={cn("h-4 w-4 shrink-0", inside ? "text-sidebar-primary" : "text-muted-foreground")} strokeWidth={1.75} />
        <span className="min-w-0 flex-1 truncate text-start">{label}</span>
        <ChevronRight
          className={cn(
            "h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform duration-150",
            isRtl && "rotate-180",
            isOpen && (isRtl ? "-rotate-90" : "rotate-90")
          )}
        />
      </CollapsibleTrigger>
      <CollapsibleContent className={cn("space-y-0.5 border-s pt-0.5", nested ? "ms-[15px] ps-1.5" : "ms-[17px] ps-2")}>
        {items.map((i) => (
          <NavItem key={i.to} nested to={i.to} icon={i.icon} label={i.label} locked={i.locked} />
        ))}
      </CollapsibleContent>
    </Collapsible>
  );
}

function NavItem({
  to,
  icon: Icon,
  label,
  locked,
  trailing,
  nested,
  end,
}: {
  to: string;
  icon: LucideIcon;
  label: string;
  locked?: boolean;
  trailing?: React.ReactNode;
  nested?: boolean;
  end?: boolean;
}) {
  return (
    <NavLink to={to} end={end} className={({ isActive }) => itemClass(isActive, nested)}>
      {({ isActive }) => (
        <>
          <Icon
            className={cn(
              "h-4 w-4 shrink-0",
              isActive ? "text-sidebar-primary" : "text-muted-foreground group-hover:text-sidebar-accent-foreground"
            )}
            strokeWidth={1.75}
          />
          <span className="min-w-0 flex-1 truncate">{label}</span>
          {locked && <Lock className="h-3 w-3 shrink-0 text-muted-foreground" aria-hidden="true" />}
          {trailing}
        </>
      )}
    </NavLink>
  );
}

function RoomUnread({ n }: { n: number }) {
  if (!n) return null;
  return (
    <span className="flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold leading-none text-white">
      {n > 99 ? "99+" : n}
    </span>
  );
}

function SectionLabel({ children, action }: { children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="flex h-7 items-center justify-between px-2.5">
      <span className="text-2xs font-medium uppercase tracking-wider text-muted-foreground rtl:normal-case rtl:tracking-normal rtl:text-xs">
        {children}
      </span>
      {action}
    </div>
  );
}

const Sidebar = () => {
  const { user, logout } = useAuth();
  const { language } = useLanguage();
  const { rooms, enrollments } = useCourses();
  const { roomId } = useParams();
  const navigate = useNavigate();
  const [openRooms, setOpenRooms] = useState<Record<string, boolean>>({});
  const isProfessor = user?.role === "professor";
  const isRtl = language === "ar";
  const { can, enforced, access, hasModule } = useAccess();
  const brand = useBrand(language);
  const { feature } = useAppSettings();
  // module affiché : allumé dans Personnalisation ET inclus dans l'offre (sinon masqué)
  // Élève : en plus, module ouvert par son professeur pour sa classe (Habilitations)
  const classModule = useClassModule();
  const show = (m: Parameters<typeof feature>[0]) => feature(m) && hasModule(m) && classModule(m);
  // Élève : fonctions accordées par l'offre de son professeur
  const studentFeatures = useStudentFeatures(isProfessor ? undefined : user?.id);
  const lab3d = useLab3dFeatures();
  const chat = useChatOptional();

  const t = (fr: string, ar: string, en: string = fr) =>
    language === "ar" ? ar : language === "fr" ? fr : en;

  // Élève : classes de ses inscriptions ou classe d'affectation directe
  const getEnrolledRooms = () => {
    if (isProfessor) {
      if (!can("class.view")) return []; // habilitation « Voir ses classes » retirée
      return rooms.filter((room) => room.professor_id === user?.id && !room.archived_at);
    }
    if (!user) return [];
    const studentEnrollments = enrollments.filter((e) => e.student_id === user.id);
    const enrolledRoomIds = [...new Set(studentEnrollments.map((e) => e.room_id).filter(Boolean))];
    if (user.room_id) enrolledRoomIds.push(user.room_id);
    return rooms.filter((room) => room.is_visible && enrolledRoomIds.includes(room.id));
  };

  const userRooms = getEnrolledRooms();

  const toggleRoom = (id: string) => {
    setOpenRooms((prev) => {
      const current = prev[id] ?? roomId === id;
      return { ...prev, [id]: !current };
    });
  };

  const handleLogout = async () => {
    try {
      await logout();
    } finally {
      navigate("/login", { replace: true });
    }
  };

  const studentRoomName =
    !isProfessor && user?.room_id ? rooms.find((r) => r.id === user.room_id)?.name : userRooms[0]?.name;

  const roleLabel = isProfessor ? t("Professeur", "أستاذ", "Teacher") : t("Élève", "تلميذ", "Student");

  return (
    <div
      dir={isRtl ? "rtl" : "ltr"}
      className="flex h-full max-h-full w-full select-none flex-col overflow-hidden bg-sidebar text-sidebar-foreground"
    >
      {/* Identité */}
      <div className="flex h-14 flex-shrink-0 items-center px-4">
        <NavLink to="/dashboard" className="flex min-w-0 items-center gap-2.5 rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          <BrandMark logoUrl={brand.logoUrl} alt={brand.appName} size="sm" />
          <div className="min-w-0 leading-tight">
            <p className="truncate text-sm font-semibold text-foreground" title={brand.appName}>
              {brand.appName}
            </p>
            <p className="truncate text-2xs text-muted-foreground">
              {brand.customTagline ||
                (isProfessor ? t("Espace enseignant", "فضاء الأستاذ", "Teacher space") : t("Espace élève", "فضاء التلميذ", "Student space"))}
            </p>
          </div>
        </NavLink>
      </div>

      <nav
        aria-label={t("Navigation principale", "التنقل الرئيسي", "Main navigation")}
        className="custom-scrollbar min-h-0 flex-1 space-y-5 overflow-y-auto overflow-x-hidden px-2.5 pb-4 pt-2"
      >
        <div className="space-y-0.5">
          <NavItem to="/dashboard" icon={LayoutGrid} label={t("Tableau de bord", "لوحة القيادة", "Dashboard")} />
          {show("chat") && chat?.enabled && (
            <NavItem
              to="/messages"
              icon={MessageCircle}
              label={t("Messages", "الرسائل", "Messages")}
              locked={isProfessor && !can("chat.students")}
              trailing={<ChatUnreadBadge />}
            />
          )}
        </div>

        <div className="space-y-0.5">
          <SectionLabel
            action={
              isProfessor && can("class.create") ? (
                <NavLink
                  to="/create-room"
                  className="flex h-5 w-5 items-center justify-center rounded text-muted-foreground hover:bg-sidebar-accent hover:text-foreground"
                  title={t("Créer une classe", "إنشاء قسم", "Create a class")}
                  aria-label={t("Créer une classe", "إنشاء قسم", "Create a class")}
                >
                  <Plus className="h-3.5 w-3.5" />
                </NavLink>
              ) : undefined
            }
          >
            {isProfessor ? t("Mes classes", "أقسامي", "My classes") : t("Mon apprentissage", "فضاء التعلم", "My learning")}
          </SectionLabel>

          {isProfessor ? (
            userRooms.length === 0 ? (
              <p className="px-2.5 py-1.5 text-xs text-muted-foreground">
                {t("Aucune classe pour l'instant", "لا يوجد أي قسم بعد", "No classes yet")}
              </p>
            ) : (
              userRooms.map((room) => {
                const isOpen = openRooms[room.id] ?? roomId === room.id;
                return (
                  <Collapsible key={room.id} open={isOpen} onOpenChange={() => toggleRoom(room.id)}>
                    <CollapsibleTrigger
                      className={cn(
                        "group flex h-9 w-full items-center gap-2.5 rounded-md px-2.5 text-[13px] font-medium transition-colors",
                        roomId === room.id ? "text-foreground" : "text-sidebar-foreground",
                        "hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground"
                      )}
                    >
                      <span
                        className={cn(
                          "flex h-4 w-4 shrink-0 items-center justify-center rounded-[4px] text-[9px] font-semibold uppercase",
                          roomId === room.id ? "bg-sidebar-primary text-sidebar-primary-foreground" : "bg-muted text-muted-foreground"
                        )}
                        aria-hidden="true"
                      >
                        {room.name.trim().charAt(0)}
                      </span>
                      <span className="min-w-0 flex-1 truncate text-start">{room.name}</span>
                      <ChevronRight
                        className={cn(
                          "h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform duration-150",
                          isRtl && "rotate-180",
                          isOpen && (isRtl ? "-rotate-90" : "rotate-90")
                        )}
                      />
                    </CollapsibleTrigger>
                    <CollapsibleContent className="ms-[17px] space-y-0.5 border-s ps-2 pt-0.5">
                      {show("students") && (
                        <NavItem nested to={`/rooms/${room.id}/students`} icon={Users} label={t("Élèves", "التلاميذ", "Students")} />
                      )}
                      {show("chat") && chat?.enabled && (
                        <NavItem
                          nested
                          to={`/rooms/${room.id}/messages`}
                          icon={MessageCircle}
                          label={t("Messages", "الرسائل", "Messages")}
                          locked={!can("chat.students")}
                          trailing={<RoomUnread n={(chat.contacts || []).filter((c) => contactInRoom(c, room.id, room.name)).reduce((n, c) => n + (c.unread || 0), 0)} />}
                        />
                      )}
                      {show("courses") && (
                        <NavItem nested to={`/rooms/${room.id}/courses`} icon={BookOpen} label={t("Cours", "الدروس", "Courses")} />
                      )}
                      {show("exercises") && (
                        <NavItem nested to={`/rooms/${room.id}/exercises`} icon={FileText} label={t("Exercices", "التمارين", "Exercises")} />
                      )}
                      {show("exams") && (
                        <SubMenu
                          nested
                          isRtl={isRtl}
                          icon={CalendarClock}
                          label={t("Exams programmés", "الامتحانات المبرمجة", "Scheduled exams")}
                          items={[
                            { to: `/rooms/${room.id}/exams`, icon: ClipboardCheck, label: t("Exams", "الامتحانات", "Exams") },
                            { to: `/rooms/${room.id}/quizzes`, icon: Timer, label: t("Quiz programmés", "الاختبارات المبرمجة", "Scheduled quizzes") },
                          ]}
                        />
                      )}
                      {show("homework") && (
                        <SubMenu
                          nested
                          isRtl={isRtl}
                          icon={GraduationCap}
                          label={t("Exams", "الامتحانات", "Exams")}
                          items={[
                            { to: `/rooms/${room.id}/homework`, icon: House, label: t("Devoirs maison", "الفروض المنزلية", "Homework"), locked: !can("homework.manage") },
                            { to: `/rooms/${room.id}/exam-examples`, icon: FolderOpen, label: t("Exemples devoirs", "نماذج الفروض", "Sample exams"), locked: !can("homework.manage") },
                          ]}
                        />
                      )}
                      {show("meet") && (
                        <NavItem
                          nested
                          to={`/rooms/${room.id}/meet`}
                          icon={Video}
                          label={t("Réunions", "الاجتماعات", "Meetings")}
                          locked={!can("meet.host")}
                        />
                      )}
                      <NavItem nested to={`/rooms/${room.id}/whiteboard`} icon={PenLine} label={t("Tableau blanc", "السبورة البيضاء", "Whiteboard")} />
                      {show("studentActivities") && (
                        <NavItem
                          nested
                          to={`/rooms/${room.id}/students-activities`}
                          icon={Activity}
                          label={t("Suivi et classement", "التتبع والترتيب", "Tracking & ranking")}
                          locked={!can("student.activity_view")}
                        />
                      )}
                      {show("attendance") && (
                        <NavItem
                          nested
                          to={`/rooms/${room.id}/attendance`}
                          icon={CalendarCheck}
                          label={t("Appel", "الحضور والغياب", "Attendance")}
                          locked={!can("attendance.manage")}
                        />
                      )}
                      {show("followUp") && (
                        <NavItem
                          nested
                          to={`/rooms/${room.id}/follow-up`}
                          icon={Layers}
                          label={t("Groupes et bilans", "المجموعات والحصائل", "Groups & reports")}
                          locked={!can("student.view")}
                        />
                      )}
                      {show("gradebook") && (
                        <NavItem
                          nested
                          to={`/rooms/${room.id}/gradebook`}
                          icon={Table2}
                          label={t("Carnet de notes", "دفتر النقط", "Gradebook")}
                          locked={!can("gradebook.manage")}
                        />
                      )}
                      {show("lessonLog") && (
                        <NavItem nested to={`/rooms/${room.id}/lesson-log`} icon={BookOpenCheck} label={t("Cahier de textes", "دفتر النصوص", "Lesson log")} />
                      )}
                      {show("calendar") && (
                        <NavItem nested to={`/rooms/${room.id}/calendar`} icon={CalendarDays} label={t("Calendrier", "اليومية", "Calendar")} locked={!can("class.calendar")} />
                      )}
                      <NavItem
                        nested
                        to={`/rooms/${room.id}/permissions`}
                        icon={ShieldCheck}
                        label={t("Habilitations", "صلاحيات التلاميذ", "Student access")}
                        locked={!can("class.edit")}
                      />
                    </CollapsibleContent>
                  </Collapsible>
                );
              })
            )
          ) : (
            <>
              {show("meet") && <NavItem to="/meetings" icon={Video} label={t("Réunions en direct", "الاجتماعات المباشرة", "Live meetings")} />}
              {classModule("whiteboard") && <NavItem to="/whiteboards" icon={PenLine} label={t("Tableaux blancs", "السبورات البيضاء", "Whiteboards")} />}
              {show("courses") && <NavItem to="/courses" icon={BookOpen} label={t("Cours", "الدروس", "Courses")} />}
              {show("exercises") && <NavItem to="/exercises" icon={FileText} label={t("Exercices", "التمارين", "Exercises")} />}
              {show("exams") && (
                <SubMenu
                  isRtl={isRtl}
                  icon={CalendarClock}
                  label={t("Exams programmés", "الامتحانات المبرمجة", "Scheduled exams")}
                  items={[
                    { to: "/exams", icon: ClipboardCheck, label: t("Exams", "الامتحانات", "Exams") },
                    { to: "/quizzes", icon: Timer, label: t("Quiz programmés", "الاختبارات المبرمجة", "Scheduled quizzes") },
                  ]}
                />
              )}
              {feature("homework") && hasModule("homework") && (
                <SubMenu
                  isRtl={isRtl}
                  icon={GraduationCap}
                  label={t("Exams", "الامتحانات", "Exams")}
                  items={[
                    ...(classModule("homework") ? [{ to: "/homework", icon: House, label: t("Devoirs maison", "الفروض المنزلية", "Homework") }] : []),
                    ...(classModule("examples") ? [{ to: "/exam-examples", icon: FolderOpen, label: t("Exemples devoirs", "نماذج الفروض", "Sample exams") }] : []),
                  ]}
                />
              )}
              {show("lessonLog") && <NavItem to="/lesson-log" icon={BookOpenCheck} label={t("Cahier de textes", "دفتر النصوص", "Lesson log")} />}
              {show("calendar") && <NavItem to="/calendar" icon={CalendarDays} label={t("Calendrier", "اليومية", "Calendar")} locked={!can("class.calendar")} />}
              {show("progress") && studentFeatures?.progress && <NavItem to="/progress" icon={TrendingUp} label={t("Ma progression", "تقدمي", "My progress")} />}
              {show("lab3d") && lab3d?.use && <NavItem to="/lab3d" icon={Boxes} label={t("Labo 3D · AR / VR", "المختبر ثلاثي الأبعاد", "3D Lab · AR / VR")} />}
            </>
          )}
        </div>

        {isProfessor && (
          <div className="space-y-0.5">
            <SectionLabel>{t("Outils", "الأدوات", "Tools")}</SectionLabel>
            {show("calendar") && <NavItem to="/calendar" icon={CalendarDays} label={t("Calendrier", "اليومية", "Calendar")} locked={!can("class.calendar")} />}
            {show("meet") && <NavItem to="/meetings" icon={Video} label={t("Réunions vidéo", "اجتماعات الفيديو", "Video meetings")} locked={!can("meet.host")} />}
            <NavItem to="/whiteboards" icon={PenLine} label={t("Tableaux blancs", "السبورات البيضاء", "Whiteboards")} />
            {show("questionBank") && <NavItem to="/question-bank" icon={Library} label={t("Banque de questions", "بنك الأسئلة", "Question bank")} locked={!can("quiz.bank")} />}
            {show("lessonPlans") && <NavItem to="/lesson-plans" icon={Sparkles} label={t("Fiches pédagogiques", "الجذاذات", "Lesson plans")} locked={!can("ai.lesson_plan")} />}
            {show("reports") && (
              <NavItem to="/reports" icon={BarChart3} label={t("Rapports", "التقارير", "Reports")} locked={!can("reports.view")} />
            )}
            {show("diagnostic") && (
              <NavItem
                to="/diagnostic"
                icon={FileSpreadsheet}
                label={t("Évaluation diagnostique", "التقويم التشخيصي", "Diagnostic assessment")}
                locked={!can("diagnostic.use")}
              />
            )}
            {show("lab3d") && <NavItem to="/lab3d" icon={Boxes} label={t("Labo 3D · AR / VR", "المختبر ثلاثي الأبعاد", "3D Lab · AR / VR")} locked={!can("lab3d.use")} />}
            {show("pdfEditor") && (
              <NavItem to="/pdf-editor" icon={FilePen} label={t("Éditeur PDF", "محرر PDF", "PDF editor")} locked={!can("pdf.use")} />
            )}
            {show("office") && <OfficeMenu t={t} isRtl={isRtl} />}
            {show("geogebra") && <GeoGebraMenu t={t} isRtl={isRtl} />}
            {show("classManagement") && <NavItem to="/class-management" icon={FolderKanban} label={t("Gestion des classes", "إدارة الأقسام", "Manage classes")} />}
            {show("library") && <NavItem to="/library" icon={LibraryBig} label={t("Bibliothèque partagée", "المكتبة المشتركة", "Shared library")} locked={!can("library.import")} />}
            {show("support") && <NavItem to="/support" icon={LifeBuoy} label={t("Aide et support", "المساعدة والدعم", "Help & support")} locked={!can("support.tickets")} />}
          </div>
        )}

        <div className="space-y-0.5">
          <SectionLabel>{t("Compte", "الحساب", "Account")}</SectionLabel>
          <NavItem to="/profile" icon={UserRound} label={t("Mon profil", "الملف الشخصي", "My profile")} />
          {isProfessor && enforced && (
            <NavItem
              to="/subscription"
              icon={CreditCard}
              label={t("Abonnement", "الاشتراك", "Subscription")}
              trailing={
                access?.subscription?.plan_name ? (
                  <span className="max-w-[84px] truncate rounded border px-1.5 text-2xs text-muted-foreground">
                    {access.subscription.plan_name}
                  </span>
                ) : undefined
              }
            />
          )}
          <NavItem to="/settings" icon={Settings} label={t("Paramètres", "الإعدادات", "Settings")} />
        </div>
      </nav>

      {/* Compte connecté */}
      <div className="flex-shrink-0 space-y-1 border-t p-2.5">
        <div className="flex items-center gap-1 px-1">
          <LanguageSelector placement="top" align="start" />
          <ThemeToggle placement="top" align="start" />
        </div>
        <div className="flex items-center gap-2.5 rounded-md p-1.5">
          <Avatar className="h-8 w-8 rounded-md">
            <AvatarImage src={user?.avatar_url} alt="" className="object-cover" />
            <AvatarFallback className="rounded-md bg-muted text-xs font-medium text-foreground">{initialsOf(user?.name)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1 leading-tight">
            <p className="truncate text-[13px] font-medium text-foreground">{user?.name || t("Utilisateur", "مستخدم", "User")}</p>
            <p className="truncate text-2xs text-muted-foreground">
              {roleLabel}
              {studentRoomName && !isProfessor ? ` · ${studentRoomName}` : ""}
            </p>
          </div>
          <button
            type="button"
            onClick={handleLogout}
            className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
            title={t("Déconnexion", "تسجيل الخروج", "Log out")}
            aria-label={t("Déconnexion", "تسجيل الخروج", "Log out")}
          >
            <LogOut className={cn("h-4 w-4", isRtl && "rotate-180")} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
